package com.tictim.ttmpcore.entity;

import java.util.List;
import java.util.function.Consumer;
import com.google.common.collect.Lists;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class TickManager extends Entity{
	private static final List<Consumer<World>> onRemoteList = Lists.newArrayList();
	private static final List<Consumer<World>> onNotRemoteList = Lists.newArrayList();
	
	public static void addTask(Consumer<World> task, boolean tickOnRemote, boolean tickOnNotRemote){
		if(tickOnRemote) onRemoteList.add(task);
		if(tickOnNotRemote) onNotRemoteList.add(task);
	}
	
	public TickManager(World world){
		super(world);
		this.forceSpawn = true;
	}
	
	@Override
	public void onUpdate(){
		for(Consumer<World> e : this.world.isRemote ? onRemoteList : onNotRemoteList){
			e.accept(this.world);
		}
	}
	
	@Override
	public boolean shouldRenderInPass(int pass){
		return false;
	}
	
	@Override
	public void onKillCommand(){}
	
	@Override
	protected void entityInit(){}
	
	@Override
	protected void readEntityFromNBT(NBTTagCompound compound){}
	
	@Override
	protected void writeEntityToNBT(NBTTagCompound compound){}
}
