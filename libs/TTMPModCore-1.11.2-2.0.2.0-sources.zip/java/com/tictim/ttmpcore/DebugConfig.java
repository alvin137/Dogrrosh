package com.tictim.ttmpcore;

import java.util.List;
import com.google.common.collect.Lists;
import com.tictim.ttmpcore.api.config.Config;
import com.tictim.ttmpcore.api.config.Configs;

public final class DebugConfig{
	private DebugConfig(){}
	
	public static final List<Config> list = Lists.newArrayList();
	
	public static final Config<Boolean> BOOLEAN_TEST = Configs.boolConfig(list, "master", "BOOLEAN_TEST", "", true).setHaveToSync(null);
	public static final Config<Double> DOUBLE_TEST = Configs.doubleConfig(list, "master", "DOUBLE_TEST", "", 0.0, -10.0, 10.0).setHaveToSync(null);
	public static final Config<Integer> INTEGER_TEST = Configs.intConfig(list, "master", "INTEGER_TEST", "", 0, -10, 10).setHaveToSync(null);
	public static final Config<String> STRING_TEST = Configs.stringConfig(list, "master", "STRING_TEST", "", "hello world!").setHaveToSync(null);
}
