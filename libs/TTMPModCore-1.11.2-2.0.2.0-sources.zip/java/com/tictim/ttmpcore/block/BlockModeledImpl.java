package com.tictim.ttmpcore.block;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class BlockModeledImpl extends BlockModeled{
	public BlockModeledImpl(String modid, String name, Material material, SoundType sound){
		super(material);
		this.setSoundType(sound).setUnlocalizedName(name).setRegistryName(modid, name);
	}
}
