package com.tictim.ttmpcore.block;

import com.tictim.ttmpcore.common.Modeled;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.DefaultStateMapper;
import net.minecraft.client.renderer.block.statemap.IStateMapper;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockModeled extends Block implements Modeled<ItemBlock>{
	public BlockModeled(Material material){
		super(material);
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void registerModels(ItemBlock inst){
		ModelLoader.setCustomStateMapper(this, getBlockStateMapper());
		ModelLoader.setCustomModelResourceLocation(inst, 0, new ModelResourceLocation(inst.getRegistryName(), "inventory"));
	}
	
	@SideOnly(Side.CLIENT)
	protected IStateMapper getBlockStateMapper(){
		return new DefaultStateMapper();
	}
}
