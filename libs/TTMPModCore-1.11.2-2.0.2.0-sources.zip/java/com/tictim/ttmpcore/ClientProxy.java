package com.tictim.ttmpcore;

import com.tictim.ttmpcore.api.common.TCreativeTab;
import com.tictim.ttmpcore.api.util.TUtils;
import com.tictim.ttmpcore.common.Modeled;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.registry.IForgeRegistryEntry;

public class ClientProxy extends CommonProxy{
	@Override
	public void adjustMods(FMLPostInitializationEvent event){
		TCreativeTab.BLOCK.setIcon(ICON_BLOCK, 0);
		TCreativeTab.ITEM.setIcon(ICON_ITEM, 0);
		TCreativeTab.MACHINE.setIcon(ICON_MACHINE, 0);
		TCreativeTab.TOOL.setIcon(ICON_TOOL, 0);
		TCreativeTab.COMBAT.setIcon(ICON_COMBAT, 0);
	}
	
	@Override
	public Item register(Item i){
		super.register(i);
		if(i instanceof Modeled) registerModel((Modeled&IForgeRegistryEntry)i, i);
		return i;
	}
	
	@Override
	public ItemBlock register(Block b, boolean doRegisterBlock){
		if(doRegisterBlock){
			ItemBlock bItem = super.register(b, doRegisterBlock);
			if(b instanceof Modeled) registerModel((Modeled&IForgeRegistryEntry)b, bItem);
			return bItem;
		}else{
			super.register(b, doRegisterBlock);
			return null;
		}
	}
	
	private static <T extends Modeled & IForgeRegistryEntry> void registerModel(T registerable, Item item){
		try{
			registerable.registerModels(item);
		}catch(ClassCastException e){
			TUtils.LOGGER.error("ClassCastException on "+registerable.getRegistryName()+" item register.", e);
		}
	}
}
