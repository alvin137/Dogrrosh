package com.tictim.ttmpcore;

import com.google.common.collect.Multimap;
import com.tictim.ttmpcore.api.common.TCreativeTab;
import com.tictim.ttmpcore.api.config.Configs;
import com.tictim.ttmpcore.api.util.TUtils;
import com.tictim.ttmpcore.common.ItemBlockProvider;
import com.tictim.ttmpcore.common.OreRegisterable;
import com.tictim.ttmpcore.item.ItemModeled;
import net.minecraft.block.Block;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CommonProxy{
	public static final Item BOOK_CQC, ICON_ITEM, ICON_TOOL, ICON_COMBAT, ICON_BLOCK, ICON_MACHINE;
	
	static{
		BOOK_CQC = new ItemModeled(){
			@Override
			public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot equipmentSlot, ItemStack stack){
				Multimap<String, AttributeModifier> multimap = super.getAttributeModifiers(equipmentSlot, stack);
				if(equipmentSlot==EntityEquipmentSlot.MAINHAND){
					multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(), new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", 1.5, 0));
					multimap.put(SharedMonsterAttributes.ATTACK_SPEED.getName(), new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", -2.4000000953674316D, 0));
				}
				return multimap;
			}
			
			@Override
			public EnumRarity getRarity(ItemStack stack){
				return EnumRarity.UNCOMMON;
			}
		}.setMaxStackSize(1).setCreativeTab(TCreativeTab.COMBAT.get()).setRegistryName(TTMPMod.MODID, "bookcqc").setUnlocalizedName("bookCQC");
		ICON_ITEM = new ItemModeled().setRegistryName(TTMPMod.MODID, "icontabitems");
		ICON_TOOL = new ItemModeled().setRegistryName(TTMPMod.MODID, "icontabtools");
		ICON_COMBAT = new ItemModeled().setRegistryName(TTMPMod.MODID, "icontabcombat");
		ICON_BLOCK = new ItemModeled().setRegistryName(TTMPMod.MODID, "icontabblocks");
		ICON_MACHINE = new ItemModeled().setRegistryName(TTMPMod.MODID, "icontabmachines");
	}
	
	public void registerBlockAndItem(FMLPreInitializationEvent event){
		register(BOOK_CQC);
		register(ICON_ITEM);
		register(ICON_TOOL);
		register(ICON_COMBAT);
		register(ICON_BLOCK);
		register(ICON_MACHINE);
	}
	
	public void registerEvent(FMLPreInitializationEvent event){
		MinecraftForge.EVENT_BUS.register(TTMPMod.instance);
	}
	
	public void loadConfig(FMLPreInitializationEvent event){
		Configs.loadConfig(event.getModConfigurationDirectory().getAbsolutePath(), TTMPMod.MODID, CoreConfig.list);
		if(TUtils.isDevEnv()||CoreConfig.DEBUG_CONFIG.get()){
			Configs.loadConfig(event.getModConfigurationDirectory().getAbsolutePath(), "configtest", DebugConfig.list);
		}
	}
	
	public void adjustMods(FMLPostInitializationEvent event){
		// Client-sided
	}
	
	public Item register(Item i){
		GameRegistry.register(i);
		if(i instanceof OreRegisterable) ((OreRegisterable)i).registerOreDictionary();
		return i;
	}
	
	public ItemBlock register(Block b, boolean doRegisterItemBlock){
		GameRegistry.register(b);
		if(doRegisterItemBlock){
			ItemBlock ib = (ItemBlock)register(getItemBlock(b).setRegistryName(b.getRegistryName()));
			if(b instanceof OreRegisterable) ((OreRegisterable)b).registerOreDictionary();
			return ib;
		}else return null;
	}
	
	protected ItemBlock getItemBlock(Block b){
		if(b instanceof ItemBlockProvider) return ((ItemBlockProvider)b).getItemBlock(b);
		else return new ItemBlock(b);
	}
}
