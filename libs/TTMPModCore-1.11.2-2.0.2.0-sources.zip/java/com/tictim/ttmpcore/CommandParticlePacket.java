package com.tictim.ttmpcore;

import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import com.tictim.ttmpcore.network.MessageParticle;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.potion.Potion;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * /sendParticle (String)particleId (Int)particleAmount (Double)X Y Z (int) colors...
 */
public class CommandParticlePacket extends CommandBase{
	private static final Vec3d RAD = new Vec3d(100.5, 30.0, 100.5);
	
	@Override
	public String getName(){
		return "sendParticle";
	}
	
	@Override
	public String getUsage(ICommandSender sender){
		return "commands.sendParticle.usage";
	}
	
	@Override
	public int getRequiredPermissionLevel(){
		return 1;
	}
	
	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException{
		//TTMPMod.logger.info(TTMPStringUtils.arrayToString(args, "Command [", ", ", "]"));
		if(args.length<5) throw new WrongUsageException("commands.sendParticle.usage");
		EnumParticleTypes particle = EnumParticleTypes.getByName(args[0]);
		if(particle==null) throw new CommandException("commands.sendParticle.exception.0", args[0]);
		int particleAmount = CommandBase.parseInt(args[1], 1);
		CoordinateArg x = CommandBase.parseCoordinate(sender.getPositionVector().xCoord, args[2], true),
				y = CommandBase.parseCoordinate(sender.getPositionVector().yCoord, args[3], false),
				z = CommandBase.parseCoordinate(sender.getPositionVector().zCoord, args[4], true);
		
		int[] colors;
		if(args.length>=6){
			colors = new int[args.length-5];
			for(int i = 5; i<args.length; i++){
				colors[i-5] = CommandBase.parseInt(args[i], 0x000000, 0xFFFFFF);
			}
		}else colors = new int[]{0xFFFFFF};
		new MessageParticle(sender.getEntityWorld().provider.getDimension(), new Vec3d(x.getResult(), y.getResult(), z.getResult())).append(particle.getParticleID(), particleAmount, 3, 3, 3, 0, 0, 0, colors).sendToAllAround();
	}
	
	@Override
	public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos){
		return args.length==1 ? getListOfStringsMatchingLastWord(args, EnumParticleTypes.getParticleNames()) : (args.length==2 ? getListOfStringsMatchingLastWord(args, Potion.REGISTRY.getKeys()) : (args.length==5 ? getListOfStringsMatchingLastWord(args, new String[]{"true", "false"}) : Collections.<String>emptyList()));
	}
}
