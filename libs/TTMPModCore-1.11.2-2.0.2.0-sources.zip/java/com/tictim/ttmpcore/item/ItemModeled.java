package com.tictim.ttmpcore.item;

import com.tictim.ttmpcore.common.Modeled;
import net.minecraft.item.Item;

public class ItemModeled extends Item implements Modeled<Item>{}
