package com.tictim.ttmpcore.common;

import java.util.function.Consumer;
import com.tictim.ttmpcore.TTMPMod;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public final class TRegistry{
	private TRegistry(){}
	
	public static void register(Item i){
		TTMPMod.proxy.register(i);
	}
	
	public static void register(Block b){
		register(b, true);
	}
	
	public static void register(Block b, boolean doRegisterItemBlock){
		TTMPMod.proxy.register(b, doRegisterItemBlock);
	}
}
