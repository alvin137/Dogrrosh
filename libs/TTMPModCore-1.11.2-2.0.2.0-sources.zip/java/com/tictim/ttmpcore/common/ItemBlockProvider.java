package com.tictim.ttmpcore.common;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;

@FunctionalInterface
public interface ItemBlockProvider<T extends Block>{
	ItemBlock getItemBlock(T inst);
}
