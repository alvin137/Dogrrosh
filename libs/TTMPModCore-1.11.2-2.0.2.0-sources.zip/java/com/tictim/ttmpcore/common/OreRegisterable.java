package com.tictim.ttmpcore.common;

@FunctionalInterface
public interface OreRegisterable{
	void registerOreDictionary();
}
