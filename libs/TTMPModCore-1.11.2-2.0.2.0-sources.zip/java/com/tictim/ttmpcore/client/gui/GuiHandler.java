package com.tictim.ttmpcore.client.gui;

import java.util.List;
import com.google.common.collect.Lists;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandler implements IGuiHandler{
	private final List<IGuiHandler> guiHandlers = Lists.newArrayList();
	
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z){
		return guiHandlers.get(ID).getServerGuiElement(ID, player, world, x, y, z);
	}
	
	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z){
		IGuiHandler cache = guiHandlers.get(ID);
		if(world.isRemote) return cache.getClientGuiElement(ID, player, world, x, y, z);
		else return cache.getServerGuiElement(ID, player, world, x, y, z);
	}
	
	public int append(IGuiHandler guiHandler){
		guiHandlers.add(guiHandler);
		return guiHandlers.size()-1;
	}
}
