package com.tictim.ttmpcore.network;

import com.tictim.ttmpcore.api.util.TUtils;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class TTMPNetworkManager{
	private final SimpleNetworkWrapper networkWrapper;
	private int disc = 0;
	
	public TTMPNetworkManager(String modid){
		networkWrapper = NetworkRegistry.INSTANCE.newSimpleChannel(modid);
	}
	
	public SimpleNetworkWrapper getNetwork(){
		return this.networkWrapper;
	}
	
	public <REQ extends IMessage, REPLY extends IMessage> void registerMessage(Class<? extends IMessageHandler<REQ, REPLY>> messageHandler, Class<REQ> requestMessageType, Side side){
		if(TUtils.isDevEnv()) TUtils.LOGGER.info(requestMessageType.getName()+" : "+disc);
		networkWrapper.registerMessage(messageHandler, requestMessageType, disc++, side);
	}
}
