package com.tictim.ttmpcore.network;

import com.tictim.ttmpcore.CoreConfig;
import com.tictim.ttmpcore.TTMPMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public abstract class MessageTargetPoint implements IMessage{
	protected int dimension;
	protected Vec3d pos;
	
	protected MessageTargetPoint(int dimension, Vec3d pos){
		this.dimension = dimension;
		this.pos = pos;
	}
	
	protected MessageTargetPoint(int dimension, double x, double y, double z){
		this(dimension, new Vec3d(x, y, z));
	}
	
	protected MessageTargetPoint(TargetPoint tp){
		this(tp.dimension, tp.x, tp.y, tp.z);
	}
	
	public TargetPoint getTargetPoint(){
		return new TargetPoint(dimension, pos.xCoord, pos.yCoord, pos.zCoord, CoreConfig.CLIENT_PACKET_SEND_DISTANCE.get());
	}
	
	public void sendToAllAround(){
		TTMPMod.CORE_NETWORK.getNetwork().sendToAllAround(this, getTargetPoint());
	}
	
	public void sendToDimension(){
		TTMPMod.CORE_NETWORK.getNetwork().sendToDimension(this, this.dimension);
	}
	
	@Override
	public void fromBytes(ByteBuf buf){
		NBTTagCompound nbt = ByteBufUtils.readTag(buf);
		this.dimension = nbt.getInteger("dim");
		this.pos = new Vec3d(nbt.getDouble("x"), nbt.getDouble("y"), nbt.getDouble("z"));
		readNBT(nbt);
	}
	
	@Override
	public void toBytes(ByteBuf buf){
		NBTTagCompound nbt = new NBTTagCompound();
		nbt.setInteger("dim", dimension);
		nbt.setDouble("x", pos.xCoord);
		nbt.setDouble("y", pos.yCoord);
		nbt.setDouble("z", pos.zCoord);
		writeNBT(nbt);
		ByteBufUtils.writeTag(buf, nbt);
	}
	
	public abstract void readNBT(NBTTagCompound nbt);
	
	public abstract void writeNBT(NBTTagCompound nbt);
}
