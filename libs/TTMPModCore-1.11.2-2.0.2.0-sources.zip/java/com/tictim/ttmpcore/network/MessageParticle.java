package com.tictim.ttmpcore.network;

import java.util.List;
import java.util.Random;
import com.google.common.collect.Lists;
import com.tictim.ttmpcore.api.util.NBTTypes;
import com.tictim.ttmpcore.api.util.TUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MessageParticle extends MessageTargetPoint implements Runnable{
	private static final int[] WHITE = new int[]{0xFFFFFF};
	
	private final List<ParticlePlacer> particles = Lists.newArrayList();
	
	public MessageParticle(){
		super(0, Vec3d.ZERO);
	}
	
	public MessageParticle(int dimension, Vec3d pos){
		super(dimension, pos);
	}
	
	public MessageParticle append(int particleId, int particleAmount, double xSpread, double ySpread, double zSpread, double xSpd, double ySpd, double zSpd, int[] colors, int... pars){
		particles.add(new ParticlePlacer(particleId, particleAmount, xSpread, ySpread, zSpread, xSpd, ySpd, zSpd, colors, pars));
		return this;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void run(){
		ParticleManager manager = Minecraft.getMinecraft().effectRenderer;
		for(ParticlePlacer p : particles){
			p.placeParticle(manager);
		}
	}
	
	@Override
	public void readNBT(NBTTagCompound nbt){
		NBTTagList list = nbt.getTagList("particles", NBTTypes.COMPOUND);
		for(int i = 0, j = list.tagCount(); i<j; i++){
			NBTTagCompound s = list.getCompoundTagAt(i);
			particles.add(new ParticlePlacer(s.getInteger("particleId"), s.getInteger("particleAmount"), s.getDouble("xSpread"), s.getDouble("ySpread"), s.getDouble("zSpread"), s.getDouble("xSpd"), s.getDouble("ySpd"), s.getDouble("zSpd"), s.getIntArray("colors"), s.getIntArray("pars")));
		}
	}
	
	@Override
	public void writeNBT(NBTTagCompound nbt){
		NBTTagList list = new NBTTagList();
		for(ParticlePlacer p : particles){
			NBTTagCompound subnbt = new NBTTagCompound();
			subnbt.setInteger("particleId", p.particleId);
			subnbt.setInteger("particleAmount", p.particleAmount);
			subnbt.setDouble("xSpread", p.xSpread);
			subnbt.setDouble("ySpread", p.ySpread);
			subnbt.setDouble("zSpread", p.zSpread);
			subnbt.setDouble("xSpd", p.xSpd);
			subnbt.setDouble("ySpd", p.ySpd);
			subnbt.setDouble("zSpd", p.zSpd);
			subnbt.setIntArray("colors", p.colors);
			subnbt.setIntArray("pars", p.pars);
			list.appendTag(subnbt);
		}
		nbt.setTag("particles", list);
	}
	
	private class ParticlePlacer{
		private final int particleId, particleAmount;
		private final double xSpread, ySpread, zSpread, xSpd, ySpd, zSpd;
		private final int[] colors, pars;
		
		private ParticlePlacer(int particleId, int particleAmount, double xSpread, double ySpread, double zSpread, double xSpd, double ySpd, double zSpd, int[] colors, int... pars){
			this.particleId = particleId;
			this.particleAmount = particleAmount;
			this.xSpread = xSpread;
			this.ySpread = ySpread;
			this.zSpread = zSpread;
			this.xSpd = xSpd;
			this.ySpd = ySpd;
			this.zSpd = zSpd;
			this.colors = colors.length<=0 ? WHITE : colors;
			this.pars = pars;
		}
		
		@SideOnly(Side.CLIENT)
		private void placeParticle(ParticleManager manager){
			for(int i = 0; i<particleAmount; i++){
				Random rng = TUtils.RNG;
				int currentColor = colors[rng.nextInt(colors.length)];
				Particle p = manager.spawnEffectParticle(particleId, pos.xCoord+xSpread*rng.nextGaussian(), pos.yCoord+ySpread*rng.nextGaussian(), pos.zCoord+zSpread*rng.nextGaussian(), xSpd, ySpd, zSpd, pars);
				if(p!=null){
					float r = (currentColor>>16&255)/255f, g = (currentColor>>8&255)/255f, b = (currentColor&255)/255f,
							chroma = 0.75F+rng.nextFloat()*0.25F;
					p.setRBGColorF(r*chroma, g*chroma, b*chroma);
					p.multiplyVelocity((float)ySpd);
				}
			}
		}
	}
	
	public static class Listener implements IMessageHandler<MessageParticle, IMessage>{
		@Override
		@SideOnly(Side.CLIENT)
		public IMessage onMessage(MessageParticle message, MessageContext ctx){
			Minecraft.getMinecraft().addScheduledTask(message);
			return null;
		}
	}
}
