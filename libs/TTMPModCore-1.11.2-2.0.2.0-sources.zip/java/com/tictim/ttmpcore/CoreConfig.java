package com.tictim.ttmpcore;

import java.util.List;
import com.google.common.collect.Lists;
import com.tictim.ttmpcore.api.config.Config;
import com.tictim.ttmpcore.api.config.Configs;

public final class CoreConfig{
	private CoreConfig(){}
	
	public static final List<Config> list = Lists.newArrayList();
	
	public static final Config<Boolean> GIVE_BOOKCQC_WHEN_START = Configs.boolConfig(list, "master", "GIVE_BOOKCQC_WHEN_START", "", false);
	public static final Config<Double> CLIENT_PACKET_SEND_DISTANCE = Configs.doubleConfig(list, "master", "CLIENT_PACKET_SEND_DISTANCE", "", 256.0, Double.MAX_VALUE, 0);
	public static final Config<Boolean> DEBUG_CONFIG = Configs.boolConfig(list, "master", "DEBUG_CONFIG", "", false);
}
