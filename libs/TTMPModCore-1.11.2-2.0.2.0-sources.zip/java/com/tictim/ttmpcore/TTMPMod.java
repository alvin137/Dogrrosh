package com.tictim.ttmpcore;

import com.tictim.ttmpcore.api.util.NBTTypes;
import com.tictim.ttmpcore.api.util.TItemUtils;
import com.tictim.ttmpcore.api.util.TUtils;
import com.tictim.ttmpcore.common.SimpleModContainer;
import com.tictim.ttmpcore.entity.TickManager;
import com.tictim.ttmpcore.network.MessageParticle;
import com.tictim.ttmpcore.network.PlayerLogInMessage;
import com.tictim.ttmpcore.network.TTMPNetworkManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = TTMPMod.MODID, name = TTMPMod.NAME, version = TTMPMod.VERSION, dependencies = "")
public class TTMPMod extends SimpleModContainer{
	public static final String MODID = "ttmpcore";
	public static final String NAME = "TTMPModCore";
	public static final String VERSION = "2.0.2.0";
	
	@Instance(value = MODID)
	public static TTMPMod instance;
	
	public static final TTMPNetworkManager CORE_NETWORK = new TTMPNetworkManager(MODID);
	
	@SidedProxy(clientSide = "com.tictim.ttmpcore.ClientProxy", serverSide = "com.tictim.ttmpcore.CommonProxy")
	public static CommonProxy proxy;
	
	public TTMPMod(){
		CORE_NETWORK.registerMessage(PlayerLogInMessage.Listener.class, PlayerLogInMessage.class, Side.CLIENT);
		CORE_NETWORK.registerMessage(MessageParticle.Listener.class, MessageParticle.class, Side.CLIENT);
	}
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent event){
		proxy.loadConfig(event);
		proxy.registerBlockAndItem(event);
		proxy.registerEvent(event);
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent event){
		proxy.adjustMods(event);
	}
	
	@EventHandler
	public void serverStarting(FMLServerStartingEvent event){
		event.registerServerCommand(new CommandParticlePacket());
	}
	
	@SubscribeEvent
	public void onPlayerLogin(PlayerLoggedInEvent event){
		CORE_NETWORK.getNetwork().sendTo(new PlayerLogInMessage(), (EntityPlayerMP)event.player);
		
		if(CoreConfig.GIVE_BOOKCQC_WHEN_START.get()&&!TUtils.isPlayerCreativeOrSpectator(event.player)){
			NBTTagCompound nbt = event.player.getEntityData();
			NBTTagCompound pnbt = nbt.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
			if(!pnbt.getBoolean("BookCQCGiven")){
				TItemUtils.giveStackToPlayer(event.player, new ItemStack(CommonProxy.BOOK_CQC));
				pnbt.setBoolean("BookCQCGiven", true);
				if(!nbt.hasKey(EntityPlayer.PERSISTED_NBT_TAG, NBTTypes.COMPOUND)){
					nbt.setTag(EntityPlayer.PERSISTED_NBT_TAG, pnbt);
				}
			}
		}
	}
	
	@SubscribeEvent
	public void attachCapability(AttachCapabilitiesEvent.World event){
		event.getWorld().addWeatherEffect(new TickManager(event.getWorld()));
	}
	
	@Override
	public String getModId(){
		return MODID;
	}
	
	@Override
	public String getName(){
		return NAME;
	}
	
	@Override
	public String getVersion(){
		return VERSION;
	}
}
