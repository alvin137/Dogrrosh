package com.tictim.ttmpcore.api.config;

import java.util.function.Consumer;
import javax.annotation.Nullable;

public class SimpleConfig<T> implements Config<T>{
	private final String category, name, comment;
	private final ConfigType<T> type;
	private final ConfigValueRange<T> configValueRange;
	
	private T value, serverCache;
	private boolean isServerCached;
	
	public SimpleConfig(String category, String name, String comment, ConfigType<T> type, ConfigValueRange<T> configValueRange){
		this.category = category;
		this.name = name;
		this.comment = comment;
		this.type = type;
		this.configValueRange = configValueRange;
	}
	
	@Override
	public String getCategory(){
		return category;
	}
	
	@Override
	public String getName(){
		return name;
	}
	
	@Override
	public String getComment(){
		return comment;
	}
	
	@Override
	public ConfigType<T> getType(){
		return type;
	}
	
	@Override
	public ConfigValueRange<T> getConfigValueRange(){
		return this.configValueRange;
	}
	
	@Override
	public T get(){
		return isServerSynced() ? serverCache : value;
	}
	
	@Override
	public void setValue(T newValue){
		this.value = newValue;
	}
	
	@Override
	public void syncValue(T newValue){
		this.serverCache = newValue;
	}
	
	@Override
	public boolean setServerSynced(boolean newValue){
		return isServerCached = newValue;
	}
	
	@Override
	public boolean isServerSynced(){
		return isServerCached;
	}
	
	private boolean haveToSync = false;
	private Consumer<T> eventHandler;
	
	@Override
	public SimpleConfig<T> setHaveToSync(@Nullable Consumer<T> eventHandler){
		haveToSync = true;
		this.eventHandler = eventHandler;
		return this;
	}
	
	public void onSync(){
		if(eventHandler!=null) eventHandler.accept(this.get());
	}
	
	@Override
	public boolean haveToSync(){
		return haveToSync;
	}
	
	@Override
	public String toString(){
		return this.getIdentificationString();
	}
}
