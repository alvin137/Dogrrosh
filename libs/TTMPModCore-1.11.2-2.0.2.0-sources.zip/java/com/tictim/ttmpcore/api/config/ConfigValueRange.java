package com.tictim.ttmpcore.api.config;

import javax.annotation.concurrent.Immutable;

@Immutable
public abstract class ConfigValueRange<T>{
	private ConfigValueRange(){}
	
	public static final ConfigValueRange<Boolean> TRUE = new BooleanRange(true);
	public static final ConfigValueRange<Boolean> FALSE = new BooleanRange(false);
	
	public static final class BooleanRange extends ConfigValueRange<Boolean>{
		private final boolean defaultValue;
		
		public BooleanRange(boolean defaultValue){
			this.defaultValue = defaultValue;
		}
		
		@Override
		public boolean booleanDefault(){
			return defaultValue;
		}
	}
	
	public static final class IntRange extends ConfigValueRange<Integer>{
		private final int defaultValue, maxValue, minValue;
		
		public IntRange(int defaultValue, int maxValue, int minValue){
			this.defaultValue = defaultValue;
			this.maxValue = Math.max(maxValue, minValue);
			this.minValue = Math.min(maxValue, minValue);
		}
		
		@Override
		public int intDefault(){
			return defaultValue;
		}
		
		@Override
		public int intMax(){
			return maxValue;
		}
		
		@Override
		public int intMin(){
			return minValue;
		}
	}
	
	public static final class DoubleRange extends ConfigValueRange<Double>{
		private final double defaultValue, maxValue, minValue;
		
		public DoubleRange(double defaultValue, double maxValue, double minValue){
			this.defaultValue = defaultValue;
			this.maxValue = Math.max(maxValue, minValue);
			this.minValue = Math.min(maxValue, minValue);
		}
		
		@Override
		public double doubleDefault(){
			return defaultValue;
		}
		
		@Override
		public double doubleMax(){
			return maxValue;
		}
		
		@Override
		public double doubleMin(){
			return minValue;
		}
	}
	
	public static final class StringRange extends ConfigValueRange<String>{
		private final String defaultValue;
		
		public StringRange(String defaultValue){
			this.defaultValue = defaultValue;
		}
		
		@Override
		public String stringDefault(){
			return defaultValue;
		}
	}
	
	public boolean booleanDefault(){
		return false;
	}
	
	public String stringDefault(){
		return "";
	}
	
	public int intDefault(){
		return 0;
	}
	
	public int intMax(){
		return Integer.MAX_VALUE;
	}
	
	public int intMin(){
		return 0;
	}
	
	public double doubleDefault(){
		return 0.0;
	}
	
	public double doubleMax(){
		return Double.MAX_VALUE;
	}
	
	public double doubleMin(){
		return 0.0;
	}
}
