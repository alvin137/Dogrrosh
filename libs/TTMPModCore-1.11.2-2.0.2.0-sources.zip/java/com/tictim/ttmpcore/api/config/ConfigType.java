package com.tictim.ttmpcore.api.config;

import java.util.Set;
import javax.annotation.Nullable;
import com.google.common.collect.Sets;
import com.tictim.ttmpcore.api.util.NBTTypes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.config.Configuration;

public abstract class ConfigType<T>{
	private static final Set<ConfigType<?>> configTypes = Sets.newHashSet();
	
	public static ConfigType<?> fromIdentificationString(String str){
		String s = str.split(":")[0];
		for(ConfigType<?> cft : configTypes)
			if(cft.getTypeString().equals(s)) return cft;
		throw new RuntimeException("ConfigType "+str+" does not exist.");
	}
	
	public static final ConfigType<Boolean> BOOLEAN = new ConfigType<Boolean>(Boolean.class){
		@Override
		public Boolean getConfigValue(Configuration file, int ordinal, Config<Boolean> key){
			return file.get(key.getCategory(), key.getName(), key.getConfigValueRange().booleanDefault(), key.getComment()).getBoolean();
		}
		
		@Override
		public void serializeTo(NBTTagCompound nbt, Config<Boolean> cfg){
			nbt.setBoolean(cfg.getIdentificationString(), cfg.get());
		}
		
		@Override
		public boolean sync(NBTTagCompound nbt, Config<Boolean> cfg){
			if(!nbt.hasKey(cfg.getIdentificationString(), NBTTypes.BOOLEAN)) return false;
			cfg.syncValue(nbt.getBoolean(cfg.getIdentificationString()));
			cfg.setServerSynced(true);
			return true;
		}
	};
	public static final ConfigType<Integer> INTEGER = new ConfigType<Integer>(Integer.class){
		@Override
		public Integer getConfigValue(Configuration file, int ordinal, Config<Integer> key){
			return file.get(key.getCategory(), key.getName(), key.getConfigValueRange().intDefault(), key.getComment(), key.getConfigValueRange().intMin(), key.getConfigValueRange().intMax()).getInt();
		}
		
		@Override
		public void serializeTo(NBTTagCompound nbt, Config<Integer> cfg){
			nbt.setInteger(cfg.getIdentificationString(), cfg.get());
		}
		
		@Override
		public boolean sync(NBTTagCompound nbt, Config<Integer> cfg){
			if(!nbt.hasKey(cfg.getIdentificationString(), NBTTypes.INTEGER)) return false;
			cfg.syncValue(nbt.getInteger(cfg.getIdentificationString()));
			cfg.setServerSynced(true);
			return true;
		}
	};
	public static final ConfigType<Double> DOUBLE = new ConfigType<Double>(Double.class){
		@Override
		public Double getConfigValue(Configuration file, int ordinal, Config<Double> key){
			return file.get(key.getCategory(), key.getName(), key.getConfigValueRange().doubleDefault(), key.getComment(), key.getConfigValueRange().doubleMin(), key.getConfigValueRange().doubleMax()).getDouble();
		}
		
		@Override
		public void serializeTo(NBTTagCompound nbt, Config<Double> cfg){
			nbt.setDouble(cfg.getIdentificationString(), cfg.get());
		}
		
		@Override
		public boolean sync(NBTTagCompound nbt, Config<Double> cfg){
			if(!nbt.hasKey(cfg.getIdentificationString(), NBTTypes.DOUBLE)) return false;
			cfg.syncValue(nbt.getDouble(cfg.getIdentificationString()));
			cfg.setServerSynced(true);
			return true;
		}
	};
	public static final ConfigType<String> STRING = new ConfigType<String>(String.class){
		@Override
		public String getConfigValue(Configuration file, int ordinal, Config<String> key){
			return file.get(key.getCategory(), key.getName(), key.getConfigValueRange().stringDefault(), key.getComment()).getString();
		}
		
		@Override
		public void serializeTo(NBTTagCompound nbt, Config<String> cfg){
			nbt.setString(cfg.getIdentificationString(), cfg.get());
		}
		
		@Override
		public boolean sync(NBTTagCompound nbt, Config<String> cfg){
			if(!nbt.hasKey(cfg.getIdentificationString(), NBTTypes.STRING)) return false;
			cfg.syncValue(nbt.getString(cfg.getIdentificationString()));
			cfg.setServerSynced(true);
			return true;
		}
	};
	
	private final String typeString;
	
	private ConfigType(Class<T> classOf){
		typeString = classOf.getSimpleName();
		configTypes.add(this);
	}
	
	public abstract T getConfigValue(Configuration file, int ordinal, Config<T> config);
	public abstract void serializeTo(NBTTagCompound nbt, Config<T> cfg);
	public abstract boolean sync(NBTTagCompound nbt, @Nullable Config<T> cfg);
	
	public String getTypeString(){
		return typeString;
	}
}
