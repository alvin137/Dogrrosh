package com.tictim.ttmpcore.api.common;

import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;

public class NoRenderPotion extends Potion{
	public NoRenderPotion(String modid, String name, boolean isBadEffectIn, int color){
		super(isBadEffectIn, color);
		setPotionName(modid+".effect."+name);
		REGISTRY.register(REGISTRY.getKeys().size(), new ResourceLocation(modid, name), this);
	}
}
