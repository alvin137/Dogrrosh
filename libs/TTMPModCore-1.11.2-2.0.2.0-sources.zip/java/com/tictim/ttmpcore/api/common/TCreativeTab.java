package com.tictim.ttmpcore.api.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TCreativeTab{
	public static final TCreativeTab ITEM = new TCreativeTab("tabTTMPItems");
	public static final TCreativeTab TOOL = new TCreativeTab("tabTTMPTools");
	public static final TCreativeTab COMBAT = new TCreativeTab("tabTTMPWeapons");
	public static final TCreativeTab BLOCK = new TCreativeTab("tabTTMPBlocks");
	public static final TCreativeTab MACHINE = new TCreativeTab("tabTTMPMachines");
	
	private final String name;
	private CreativeTabs creativeTab = null;
	private boolean iconModified = false;
	private ItemStack stack;
	
	public TCreativeTab(String name){
		this(name, new ItemStack(Items.STONE_PICKAXE));
	}
	
	public TCreativeTab(String name, ItemStack initialIconStack){
		this.name = name;
		this.stack = initialIconStack;
		// getCreativeTab();
	}
	
	public boolean isIconModified(){
		return iconModified;
	}
	
	public CreativeTabs get(){
		if(creativeTab==null) creativeTab = new InternalTab(name);
		return creativeTab;
	}
	
	@SideOnly(Side.CLIENT)
	public boolean setIcon(Item icon, int itemDamage){
		return setIcon(new ItemStack(icon, 1, itemDamage));
	}
	
	@SideOnly(Side.CLIENT)
	public boolean setIcon(ItemStack stack){
		if(!iconModified){
			iconModified = true;
			this.stack = stack;
			return true;
		}else return false;
	}
	
	private class InternalTab extends CreativeTabs{
		public InternalTab(String str){
			super(str);
		}
		
		@Override
		@SideOnly(Side.CLIENT)
		public ItemStack getTabIconItem(){
			return TCreativeTab.this.stack;
		}
	}
}
