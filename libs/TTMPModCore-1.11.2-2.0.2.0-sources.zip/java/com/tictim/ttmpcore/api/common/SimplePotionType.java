package com.tictim.ttmpcore.api.common;

import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;

public class SimplePotionType extends PotionType{
	private final String name;
	
	public SimplePotionType(String name, PotionEffect... effects){
		super(name, effects);
		this.name = name;
	}
	
	public void register(){
		PotionType.registerPotionType(name, this);
	}
}
