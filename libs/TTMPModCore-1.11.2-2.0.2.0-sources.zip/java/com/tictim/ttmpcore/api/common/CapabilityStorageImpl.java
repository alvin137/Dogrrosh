package com.tictim.ttmpcore.api.common;

import net.minecraft.nbt.NBTBase;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

public class CapabilityStorageImpl<NBT extends NBTBase, CAP extends ICapabilitySerializable<NBT>> implements Capability.IStorage<CAP>{
	@Override
	public NBTBase writeNBT(Capability<CAP> capability, CAP instance, EnumFacing side){
		return instance.serializeNBT();
	}
	
	@Override
	public void readNBT(Capability<CAP> capability, CAP instance, EnumFacing side, NBTBase nbt){
		instance.deserializeNBT((NBT)nbt);
	}
}
