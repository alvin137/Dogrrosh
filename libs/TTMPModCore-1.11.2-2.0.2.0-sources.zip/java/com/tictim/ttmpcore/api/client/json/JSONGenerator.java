package com.tictim.ttmpcore.api.client.json;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import com.tictim.ttmpcore.api.util.TUtils;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * JSONGenerator�� ������ Json ���� ������ �����ϰ� �ϱ� ���� ��ƿ��Ƽ Ŭ�����Դϴ�.
 * Client�� �ƴ� ȯ�濡�� �ν��Ͻ��� �����ϰų�, ���� ȯ���� �ƴ� ȯ�濡�� �ν��Ͻ��� �����ϸ� RuntimeException�� ����ŵ�ϴ�.
 */
@SideOnly(Side.CLIENT)
public final class JSONGenerator{
	private final File root;
	private final String modid;
	
	public JSONGenerator(String modid){
		if(!TUtils.isDevEnv()) throw new RuntimeException("JSON Generator in not-dev environment");
		File rc = null;
		try{
			rc = new File(new File(".").getAbsoluteFile().getParentFile().getParentFile(), "/src/main/resources/assets/"+modid+"/");
			if(!rc.exists()||!rc.isDirectory()){
				TUtils.LOGGER.error("root folder /src/main/resources/assets/"+modid+"/ does not exist");
				rc = null;
			}
		}catch(Exception e){
			TUtils.LOGGER.error("exception caught : ", e);
		}finally{
			root = rc;
		}
		this.modid = modid;
	}
	
	public String getModid(){
		return this.modid;
	}
	
	public void generateJSON(String dir, String fileName, JSONComponent value){
		generateJSON(dir, fileName, value.toString(0));
	}
	
	public void generateJSON(String dir, String fileName, String value){
		if(root!=null){
			try{
				if(!dir.endsWith("/")&&!dir.isEmpty()){
					dir += "/";
				}else if(dir.length()<=1){
					dir = "";
				}
				File f = new File(root, dir+fileName+".json");
				if(f.getParentFile()!=null&&!f.getParentFile().exists()) f.getParentFile().mkdirs();
				
				if(f.exists()){
					TUtils.LOGGER.error("JSON {} already exists.", fileName);
				}else{
					if(f.createNewFile()){
						DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
						out.writeBytes(value);
						out.close();
					}else TUtils.LOGGER.error("Failed to create file {}", f.getAbsolutePath());
				}
			}catch(IOException e){
				TUtils.LOGGER.error("IOException caught from JSONGenerator : ", e);
			}
		}
	}
}
