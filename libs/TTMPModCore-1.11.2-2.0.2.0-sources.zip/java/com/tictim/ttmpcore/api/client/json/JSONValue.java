package com.tictim.ttmpcore.api.client.json;

import com.tictim.ttmpcore.api.util.TUtils;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class JSONValue implements JSONComponent{
	private final String value;
	
	/** null */
	public JSONValue(){
		this.value = "null";
	}
	
	public JSONValue(boolean value){
		this.value = Boolean.toString(value);
	}
	
	public JSONValue(long value){
		this.value = Long.toString(value);
	}
	
	public JSONValue(int value){
		this.value = Integer.toString(value);
	}
	
	public JSONValue(float value){
		this.value = Float.toString(value);
	}
	
	public JSONValue(double value){
		this.value = Double.toString(value);
	}
	
	public JSONValue(String value){
		this.value = '\"'+value+'\"';
		if(value.contains("\"")){
			TUtils.LOGGER.warn("JSON Value { "+this.toString(0)+" } is contains quotation marks");
		}
	}
	
	public String overview(){
		return this.value;
	}
	
	@Override
	public String toString(int numberOfTabs){
		return value;
	}
}
