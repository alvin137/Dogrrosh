package com.tictim.ttmpcore.api.client.json;

import com.tictim.ttmpcore.api.util.TUtils;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class JSONPair implements JSONComponent{
	private final JSONValue key;
	private final JSONComponent value;
	
	public JSONPair(String key, boolean allowBreak, JSONPair... value){
		this(new JSONValue(key), new JSONObject(allowBreak, value));
	}
	
	public JSONPair(String key, String value){
		this(new JSONValue(key), new JSONValue(value));
	}
	
	public JSONPair(String key, JSONComponent value){
		this(new JSONValue(key), value);
	}
	
	private JSONPair(JSONValue key, JSONComponent value){
		this.key = key;
		this.value = value;
		if(!(key.overview().endsWith("\"")&&key.overview().startsWith("\""))){
			TUtils.LOGGER.warn("JSON Pair { "+this.toString(0)+" }'s key is not String");
		}
	}
	
	@Override
	public String toString(int numberOfTabs){
		return key.toString(numberOfTabs)+" : "+value.toString(numberOfTabs);
	}
	
}
