package com.tictim.ttmpcore.api.client.json;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class JSONObjArray extends JSONAppendable<JSONObject>{
	public JSONObjArray(boolean allowBreak, JSONObject... jsons){
		super(allowBreak, jsons);
	}
	
	@Override
	public String openingSignature(){
		return "[";
	}
	
	@Override
	public String closingSignature(){
		return "]";
	}
}
