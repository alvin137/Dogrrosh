package com.tictim.ttmpcore.api.client.json;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nullable;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.statemap.StateMapperBase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public final class JSONs{
	private JSONs(){}
	
	public static String getTabs(int numberOfTabs){
		if(numberOfTabs<=0) return "";
		else{
			StringBuilder stb = new StringBuilder();
			for(int i = 0; i<numberOfTabs; i++){
				stb.append('\t');
			}
			return stb.toString();
		}
	}
	
	public static JSONAppendable<JSONPair> simpleItem(String parent, String... textures){
		JSONObject jtexture = new JSONObject(true);
		for(int i = 0; i<textures.length; i++){
			jtexture.append(new JSONPair("layer"+i, textures[i]));
		}
		return new JSONObject(true, new JSONPair("parent", parent), new JSONPair("textures", jtexture));
	}
	
	public static JSONObject toOverride(Predicates predicate, String modelLocation){
		return toOverride(predicate, new JSONPair("model", modelLocation));
	}
	
	public static JSONObject toOverride(Predicates predicate, JSONPair... pairs){
		JSONObject obj = new JSONObject(true, new JSONPair("predicate", predicate.toObject()));
		obj.append(pairs);
		return obj;
	}
	
	public static JSONAppendable<JSONPair> simpleCubeAll(String textureAll){
		return new JSONObject(true, new JSONPair("parent", "block/cube_all"), new JSONPair("textures", true, new JSONPair("all", textureAll)));
	}
	
	public static JSONAppendable<JSONPair> blockStateNormal(String modelName, JSONPair... additional){
		return toBlockState(new JSONPair("normal", new JSONObject(false, new JSONPair("model", modelName)).append(additional)));
	}
	
	public static JSONAppendable<JSONPair> blockStateNormalArr(JSONObject... objects){
		return toBlockState(new JSONPair("normal", new JSONObjArray(true, objects)));
	}
	
	public static JSONAppendable<JSONPair> toBlockState(List<IBlockState> states, Function<IBlockState, JSONObject> toModel){
		return toBlockState(states.stream().map(s -> new JSONPair(blockStateToString(s.getProperties()), toModel.apply(s))).toArray(i -> new JSONPair[i]));
	}
	
	public static JSONAppendable<JSONPair> toBlockState(JSONPair... variants){
		return new JSONObject(true, new JSONPair("variants", true, variants));
	}
	
	public static ForgeStateBuilder forgeStateBuilder(BlockStateContainer states, @Nullable JSONAppendable<JSONPair> defaults){
		JSONAppendable<JSONPair> returns = new JSONObject(true, new JSONPair("forge_marker", new JSONValue(1))),
				variants = new JSONObject(true);
		if(defaults!=null) returns.append(new JSONPair("defaults", defaults));
		returns.append(new JSONPair("variants", variants));
		return new ForgeStateBuilder(returns, variants, states);
	}
	
	/** @see StateMapperBase#getPropertyString */
	public static String blockStateToString(Map<IProperty<?>, Comparable<?>> values){
		StringBuilder stb = new StringBuilder();
		for(Entry<IProperty<?>, Comparable<?>> entry : values.entrySet()){
			if(stb.length()!=0) stb.append(",");
			IProperty<?> p = entry.getKey();
			stb.append(p.getName()).append("=").append(getPropertyName(p, entry.getValue()));
		}
		return stb.length()==0 ? "normal" : stb.toString();
	}
	
	private static <T extends Comparable<T>> String getPropertyName(IProperty<T> property, Comparable<?> value){
		return property.getName((T)value);
	}
	
	private static <T extends Comparable<T>> JSONPair[] toForgeBlockStatePrv(IProperty<T> p, @Nullable Function<T, JSONPair[]> function){
		return p.getAllowedValues().stream().map(v -> {
			JSONPair[] pairs = function==null ? new JSONPair[0] : function.apply(v);
			return new JSONPair(p.getName(v), true, pairs);
		}).toArray(i -> new JSONPair[i]);
	}
	
	public static final class Predicates{
		private final List<JSONPair> pairs = Lists.newArrayList();
		
		public Predicates append(String key, float value){
			pairs.add(new JSONPair(key, new JSONValue(value)));
			return this;
		}
		
		private JSONObject toObject(){
			return new JSONObject(true, pairs.toArray(new JSONPair[pairs.size()]));
		}
	}
	
	@SideOnly(Side.CLIENT)
	public static final class ForgeStateBuilder{
		private final JSONAppendable<JSONPair> base, variants;
		private final Map<IProperty, Function> statemap = Maps.newHashMap();
		private final BlockStateContainer states;
		
		private ForgeStateBuilder(JSONAppendable<JSONPair> base, JSONAppendable<JSONPair> variants, BlockStateContainer states){
			this.base = base;
			this.variants = variants;
			this.states = states;
		}
		
		public <T extends Comparable<T>> ForgeStateBuilder with(IProperty<T> p, Function<T, JSONPair[]> func){
			statemap.put(p, func);
			return this;
		}
		
		public JSONAppendable<JSONPair> build(@Nullable Consumer<JSONObject> normalCase){
			if(states.getProperties().isEmpty()){
				JSONObject arr = new JSONObject(true);
				normalCase.accept(arr);
				variants.append(new JSONPair("normal", new JSONObjArray(false, arr)));
			}else{
				states.getProperties().stream().forEach(p -> variants.append(new JSONPair(p.getName(), true, toForgeBlockStatePrv(p, statemap.get(p)))));
			}
			return base;
		}
	}
}
