package com.tictim.ttmpcore.api.util;

import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraftforge.oredict.OreDictionary;

public final class TItemUtils{
	private TItemUtils(){}
	
	public static final String KEY_BLOCK_ENTITY_TAG = "BlockEntityTag";
	
	public static boolean hasOreDict(ItemStack stack, String oreDict){
		return !stack.isEmpty()&&OreDictionary.doesOreNameExist(oreDict)&&OreDictionary.getOres(oreDict).stream().anyMatch(t -> OreDictionary.itemMatches(stack, t, false));
	}
	
	public static ItemStack getCorrectItemStack(EntityPlayer player, Predicate<ItemStack> comparator){
		ItemStack s = player.getHeldItem(EnumHand.OFF_HAND);
		if(!s.isEmpty()&&comparator.test(s)){
			return s;
		}else{
			s = player.getHeldItem(EnumHand.MAIN_HAND);
			if(!s.isEmpty()&&comparator.test(s)){
				return s;
			}else return getCorrectItemStack(player.inventory, comparator);
		}
	}
	
	public static ItemStack getCorrectItemStack(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(!stack.isEmpty()&&comparator.test(stack)) return stack;
		}
		return ItemStack.EMPTY;
	}
	
	public static boolean hasItemStack(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(!stack.isEmpty()&&comparator.test(stack)) return true;
		}
		return false;
	}
	
	public static void giveStackToPlayer(EntityPlayer player, ItemStack stack){
		if(!player.inventory.addItemStackToInventory(stack))//try to give ItemStack in inventory
			InventoryHelper.spawnItemStack(player.world, player.posX, player.posY, player.posZ, stack); //spawn EntityItem in world
	}
	
	public static void changeCorrectItemStack(IInventory inventory, Predicate<ItemStack> comparator, Function<ItemStack, ItemStack> function){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(comparator.test(stack)) inventory.setInventorySlotContents(i, function.apply(stack));
		}
	}
	
	public static final int SLOT_NOT_FOUND = -1;
	
	public static int getCorrectStackSlot(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(comparator.test(stack)) return i;
		}
		return SLOT_NOT_FOUND;
	}
}
