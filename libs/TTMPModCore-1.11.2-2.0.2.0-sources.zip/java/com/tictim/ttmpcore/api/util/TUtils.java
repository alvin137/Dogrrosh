package com.tictim.ttmpcore.api.util;

import java.lang.reflect.Field;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.CoreModManager;

public final class TUtils{
	private TUtils(){}
	
	public static final Logger LOGGER = LogManager.getLogger("TTMPMod");
	public static final Random RNG = new Random(System.nanoTime());
	private static final boolean isDevEnv;
	
	static{
		boolean c = false;
		try{
			Field field = CoreModManager.class.getDeclaredField("deobfuscatedEnvironment");
			field.setAccessible(true);
			c = field.getBoolean(null);
		}catch(Exception e){
			e.printStackTrace();
		}
		isDevEnv = c;
	}
	
	public static <T> T getRandomIndex(T[] array, Random rng){
		return array[rng.nextInt(array.length)];
	}
	
	public static int round(double d){
		int v = MathHelper.floor(d);
		return (d-v)>0.5 ? v+1 : v;
	}
	
	public static int round(float d){
		int v = MathHelper.floor(d);
		return (d-v)>0.5f ? v+1 : v;
	}
	
	public static boolean roll(Random rng, double chance){
		return rng.nextDouble()<chance;
	}
	
	public static boolean roll(double chance){
		return Math.random()<chance;
	}
	
	public static boolean isPlayerCreativeOrSpectator(EntityPlayer p){
		return p.capabilities.isCreativeMode||p.isSpectator();
	}
	
	public static boolean canParseToInteger(String str, boolean allowNegative){
		if(str.length()>0){
			int i = 0;
			if(allowNegative){
				char c = str.charAt(i);
				if(((c=='-'||c=='+')&&str.length()>1)||Character.isDigit(c)) i++;
				else return false;
			}
			for(; i<str.length(); i++)
				if(!Character.isDigit(str.charAt(i))) return false;
			return true;
		}else return false;
	}
	
	public static double getEyePosY(Entity e){
		return e.posY+e.getEyeHeight();
	}
	
	/** @see Entity#getPositionEyes(float) */
	public static Vec3d getEyeVector(Entity e){
		return new Vec3d(e.posX, getEyePosY(e), e.posZ);
	}
	
	public static Vec3d getCenterVector(Entity e){
		return new Vec3d(e.posX, e.posY+(e.height/2f), e.posZ);
	}
	
	public static double sizeOf(AxisAlignedBB bound){
		return (bound.maxX-bound.minX)*(bound.maxY-bound.minY)*(bound.maxZ-bound.minZ);
	}
	
	public static AxisAlignedBB toAABB(Vec3d center, double rad){
		return toAABB(center.xCoord, center.yCoord, center.zCoord, rad);
	}
	
	public static AxisAlignedBB toAABB(double x, double y, double z, double rad){
		return new AxisAlignedBB(x-rad, y-rad, z-rad, x+rad, y+rad, z+rad);
	}
	
	public static AxisAlignedBB toAABB(Vec3d center, double xr, double yr, double zr){
		return toAABB(center.xCoord, center.yCoord, center.zCoord, xr, yr, zr);
	}
	
	public static AxisAlignedBB toAABB(double x, double y, double z, double xr, double yr, double zr){
		return new AxisAlignedBB(x-xr, y-yr, z-zr, x+xr, y+yr, z+zr);
	}
	
	public static final double RAD_1DEG = Math.PI/180.0;
	
	@Nullable
	public static RayTraceResult rayTrace(World world, Entity ent, double endLength, boolean useLiquids){
		return rayTrace(world, new Vec3d(ent.posX, ent.posY+ent.getEyeHeight(), ent.posZ), ent.rotationPitch, ent.rotationYaw, endLength, useLiquids);
	}
	
	@Nullable
	public static RayTraceResult rayTrace(World world, Vec3d start, double pitch, double yaw, double endLength, boolean useLiquids){
		double f4 = (-Math.cos(pitch*TUtils.RAD_1DEG))*endLength;
		Vec3d end = start.addVector(Math.sin(-yaw*TUtils.RAD_1DEG-Math.PI)*f4, Math.sin(-pitch*TUtils.RAD_1DEG)*endLength, Math.cos(-yaw*TUtils.RAD_1DEG-Math.PI)*f4);
		return world.rayTraceBlocks(start, end, useLiquids, !useLiquids, false);
	}
	
	public static Vec3d getEndPoint(World world, Entity ent, double endLength, boolean useLiquids){
		return getEndPoint(world, new Vec3d(ent.posX, ent.posY+ent.getEyeHeight(), ent.posZ), ent.rotationPitch, ent.rotationYaw, endLength, useLiquids);
	}
	
	public static Vec3d getEndPoint(World world, Vec3d start, double pitch, double yaw, double endLength, boolean useLiquids){
		double f4 = (-Math.cos(pitch*TUtils.RAD_1DEG))*endLength;
		Vec3d end = start.addVector(Math.sin(-yaw*TUtils.RAD_1DEG-Math.PI)*f4, Math.sin(-pitch*TUtils.RAD_1DEG)*endLength, Math.cos(-yaw*TUtils.RAD_1DEG-Math.PI)*f4);
		RayTraceResult result = world.rayTraceBlocks(start, end, useLiquids, !useLiquids, false);
		return result!=null ? result.hitVec : end;
	}
	
	public static final boolean isDevEnv(){
		return isDevEnv;
	}
}
