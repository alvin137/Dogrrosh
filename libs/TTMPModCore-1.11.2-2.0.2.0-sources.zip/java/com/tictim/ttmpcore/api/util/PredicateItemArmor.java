package com.tictim.ttmpcore.api.util;

import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;

public class PredicateItemArmor implements Predicate<ItemStack>, com.google.common.base.Predicate<ItemStack>{
	private final ArmorMaterial material;
	
	public PredicateItemArmor(ArmorMaterial material){
		this.material = material;
	}
	
	@Override
	public boolean apply(ItemStack stack){
		return stack!=null&&stack.getItem() instanceof ItemArmor&&((ItemArmor)stack.getItem()).getArmorMaterial()==material;
	}
	
	@Override
	public boolean test(ItemStack stack){
		return stack!=null&&stack.getItem() instanceof ItemArmor&&((ItemArmor)stack.getItem()).getArmorMaterial()==material;
	}
	
	public boolean allMatches(EntityLivingBase ent){
		Iterator<ItemStack> it = ent.getArmorInventoryList().iterator();
		while(it.hasNext()){
			if(!apply(it.next())) return false;
		}
		return true;
	}
	
	public boolean anyMatches(EntityLivingBase ent){
		Iterator<ItemStack> it = ent.getArmorInventoryList().iterator();
		while(it.hasNext()){
			if(apply(it.next())) return true;
		}
		return false;
	}
	
	public boolean matches(EntityLivingBase ent, boolean testHead, boolean testChest, boolean testLegs, boolean testFeet){
		if(testHead&&!apply(ent.getItemStackFromSlot(EntityEquipmentSlot.HEAD))) return false;
		else if(testChest&&!apply(ent.getItemStackFromSlot(EntityEquipmentSlot.CHEST))) return false;
		else if(testLegs&&!apply(ent.getItemStackFromSlot(EntityEquipmentSlot.LEGS))) return false;
		else if(testFeet&&!apply(ent.getItemStackFromSlot(EntityEquipmentSlot.FEET))) return false;
		else return true;
	}
	
	@Override
	public boolean equals(Object o){
		if(o instanceof PredicateItemArmor){
			return this.material==((PredicateItemArmor)o).material;
		}else return false;
	}
}
