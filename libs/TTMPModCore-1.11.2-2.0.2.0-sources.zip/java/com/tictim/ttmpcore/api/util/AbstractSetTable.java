package com.tictim.ttmpcore.api.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import com.google.common.collect.Sets;

public abstract class AbstractSetTable<E> implements SetTable<E>{
	protected final Set<E> sets;
	protected final Random rng;
	
	protected AbstractSetTable(){
		this.sets = Sets.newHashSet();
		this.rng = new Random(System.currentTimeMillis());
	}
	
	@Override
	public boolean add(E e){
		return this.sets.add(e);
	}
	
	@Override
	public boolean addAll(Collection<? extends E> c){
		return this.sets.addAll(c);
	}
	
	@Override
	public boolean contains(Object element){
		return this.sets.contains(element);
	}
	
	@Override
	public boolean containsAll(Collection<?> c){
		return this.sets.containsAll(c);
	}
	
	@Override
	public boolean isEmpty(){
		return this.sets.isEmpty();
	}
	
	@Override
	public Iterator<E> iterator(){
		return this.sets.iterator();
	}
	
	@Override
	public void clear(){
		this.sets.clear();
	}
	
	@Override
	public boolean remove(Object o){
		return this.sets.remove(o);
	}
	
	@Override
	public boolean removeAll(Collection<?> c){
		return this.sets.removeAll(c);
	}
	
	@Override
	public boolean retainAll(Collection<?> c){
		return this.sets.retainAll(c);
	}
	
	@Override
	public int size(){
		return this.sets.size();
	}
	
	@Override
	public Object[] toArray(){
		return this.sets.toArray();
	}
	
	@Override
	public <T> T[] toArray(T[] a){
		return this.sets.toArray(a);
	}
	
	@Override
	@Nullable
	public E get(@Nullable Collection<E> currentPool){
		int rollCount = sets.stream().mapToInt(e -> this.getRoll(e, currentPool)).sum();
		if(rollCount<=0) return null;
		int rollCache = rng.nextInt(rollCount);
		for(E element : sets){
			int roll = this.getRoll(element, currentPool);
			if(rollCache<roll) return element;
			else rollCache -= roll;
		}
		throw new RuntimeException("unexpected");
	}
	
	protected abstract int getRoll(E e, @Nullable Collection<E> currentPool);
}
