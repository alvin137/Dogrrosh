package com.tictim.ttmpcore.api.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import com.google.common.collect.Sets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class TClientUtils{
	public static final boolean isSneakKeyDown(){
		return GameSettings.isKeyDown(Minecraft.getMinecraft().gameSettings.keyBindSneak);
	}
	
	public static final boolean isSprintKeyDown(){
		return GameSettings.isKeyDown(Minecraft.getMinecraft().gameSettings.keyBindSprint);
	}
	
	/**
	 * <b>Dev only</b><br>
	 * Development Environment�� �ƴ� ȯ�濡�� ȣ���ϰ� �Ǹ� RuntimeException�� ����ŵ�ϴ�.
	 */
	public static void sortLang(String modid, String fileName){
		if(!TUtils.isDevEnv()) throw new RuntimeException("sortLang(...) in non-dev env");
		File file = new File(new File(".").getAbsoluteFile().getParentFile().getParentFile(), "/src/main/resources/assets/"+modid+"/lang/"+fileName+".lang");
		if(!file.exists()||!file.isFile()){
			TUtils.LOGGER.error("root file /src/main/resources/assets/"+modid+"/lang/"+fileName+".lang does not exist");
		}else{
			try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))){
				Set<String> set = Sets.newTreeSet();
				while(true){
					String str = reader.readLine();
					if(str==null) break;
					else if(str.contains("=")) set.add(str);
				}
				reader.close();
				if(!file.delete()){
					TUtils.LOGGER.error("cannot delete file "+file.getAbsolutePath());
					return;
				}else{
					if(file.createNewFile()){
						Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
						String c = null;
						for(String s : set){
							String cache = s.substring(0, s.indexOf("="));
							if(cache.contains(".")) cache = s.substring(0, s.indexOf("."));
							if(!cache.equals(c)){
								c = cache;
								TUtils.LOGGER.info("new lang set is %s", c);
								writer.write("\n");
							}
							writer.write(s+"\n");
						}
						writer.close();
					}else{
						TUtils.LOGGER.error("cannot re-create file "+file.getAbsolutePath());
						return;
					}
				}
			}catch(IOException e){
				TUtils.LOGGER.error(e);
			}
		}
	}
}
