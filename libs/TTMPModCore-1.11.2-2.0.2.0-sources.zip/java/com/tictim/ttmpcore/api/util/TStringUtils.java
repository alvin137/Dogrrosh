package com.tictim.ttmpcore.api.util;

import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;

public class TStringUtils{
	public static <T> String arrayToString(T[] c, String opening, String space, String closing){
		return arrayToString(c, s -> s, opening, space, closing);
	}
	
	public static <T> String arrayToString(T[] c, Function<T, ?> formatter, String opening, String space, String closing){
		return arrayToString(c, formatter, s -> true, opening, space, closing);
	}
	
	public static <T> String arrayToString(T[] c, Function<T, ?> formatter, Predicate<T> predicate, String opening, String space, String closing){
		final StringBuilder strb = new StringBuilder().append(opening);
		boolean flag = false;
		for(T t : c){
			if(flag) strb.append(space);
			else flag = !flag;
			if(predicate.test(t)) strb.append(formatter.apply(t));
		}
		return strb.append(closing).toString();
	}
	
	public static <T> String collectionToString(Iterable<T> c, String opening, String space, String closing){
		return collectionToString(c, s -> s, opening, space, closing);
	}
	
	public static <T> String collectionToString(Iterable<T> c, Function<T, ?> formatter, String opening, String space, String closing){
		return collectionToString(c, formatter, s -> true, opening, space, closing);
	}
	
	public static <T> String collectionToString(Iterable<T> c, Function<T, ?> formatter, Predicate<T> predicate, String opening, String space, String closing){
		final StringBuilder strb = new StringBuilder().append(opening);
		boolean flag = false;
		for(T t : c){
			if(flag) strb.append(space);
			else flag = !flag;
			if(predicate.test(t)) strb.append(formatter.apply(t));
		}
		return strb.append(closing).toString();
	}
	
	public static <T> String iteratorToString(Iterator<T> c, String opening, String space, String closing){
		return iteratorToString(c, s -> s, opening, space, closing);
	}
	
	public static <T> String iteratorToString(Iterator<T> c, Function<T, ?> formatter, String opening, String space, String closing){
		return iteratorToString(c, formatter, s -> true, opening, space, closing);
	}
	
	public static <T> String iteratorToString(Iterator<T> c, Function<T, ?> formatter, Predicate<T> predicate, String opening, String space, String closing){
		final StringBuilder strb = new StringBuilder().append(opening);
		boolean flag = false;
		while(c.hasNext()){
			T t = c.next();
			if(flag) strb.append(space);
			else flag = !flag;
			if(predicate.test(t)) strb.append(formatter.apply(t));
		}
		return strb.append(closing).toString();
	}
	
	public static UUID toUuid(String str){
		return UUID.nameUUIDFromBytes(str.getBytes(StandardCharsets.UTF_8));
	}
	
	public static String toUuidString(String str){
		return UUID.nameUUIDFromBytes(str.getBytes(StandardCharsets.UTF_8)).toString();
	}
}
