package com.tictim.ttmpcore.api.util;

import java.util.AbstractMap.SimpleEntry;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import com.google.common.collect.Maps;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AbstractAttributeMap;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;

public final class AttributeApplier{
	private final Map<IAttribute, Entry<AttributeModifier, AttributeModifierFactory>> attributeMap = Maps.newHashMap();
	
	public AttributeApplier addAttribute(IAttribute attribute, String uuid, String name, double amount, int operation){
		return this.addAttribute(attribute, UUID.fromString(uuid), name, amount, operation);
	}
	
	public AttributeApplier addAttribute(IAttribute attribute, UUID uuid, String name, double amount, int operation){
		return this.addAttribute(attribute, uuid, name, amount, operation, (k, v, e) -> new AttributeModifier(v.getID(), v.getName(), v.getAmount(), v.getOperation()));
	}
	
	public AttributeApplier addAttribute(IAttribute attribute, String uuid, String name, double amount, int operation, AttributeModifierFactory factory){
		return this.addAttribute(attribute, UUID.fromString(uuid), name, amount, operation, factory);
	}
	
	public AttributeApplier addAttribute(IAttribute attribute, UUID uuid, String name, double amount, int operation, AttributeModifierFactory factory){
		attributeMap.put(attribute, new SimpleEntry(new AttributeModifier(uuid, name, amount, operation), factory));
		return this;
	}
	
	public AttributeApplier clearAllAttributes(){
		attributeMap.clear();
		return this;
	}
	
	public boolean isEmpty(){
		return attributeMap.isEmpty();
	}
	
	public void applyAttribute(EntityLivingBase entity){
		AbstractAttributeMap entityAttributeMap = entity.getAttributeMap();
		attributeMap.forEach((k, v) -> {
			IAttributeInstance attributeInst = entityAttributeMap.getAttributeInstance(k);
			if(attributeInst!=null){
				attributeInst.removeModifier(v.getKey());
				attributeInst.applyModifier(v.getValue().apply(k, v.getKey(), entity));
			}
		});
	}
	
	public void removeAttribute(EntityLivingBase entity){
		AbstractAttributeMap entityAttributeMap = entity.getAttributeMap();
		attributeMap.forEach((k, v) -> {
			IAttributeInstance attributeInst = entityAttributeMap.getAttributeInstance(k);
			if(attributeInst!=null) attributeInst.removeModifier(v.getKey());
		});
	}
	
	@FunctionalInterface
	public static interface AttributeModifierFactory{
		AttributeModifier apply(IAttribute key, AttributeModifier value, EntityLivingBase entity);
	}
}
