package com.tictim.utilib;

import com.tictim.utilib.modeled.Modeled;
import com.tictim.utilib.util.ParticlePlacer;
import com.tictim.utilib.util.TCreativeTab;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;

public class ClientProxy extends CommonProxy{
	//private static boolean first = true;
	private static boolean modelBaked;
	
	@Override
	public void loadModel(){
		TCreativeTab.registerAllModels();
	}
	
	@Override
	public void registerModel(Modeled model, Item inst){
		if(!modelBaked){
			model.registerModels(inst);
		}
	}
	
	@Override
	public void markModelBaked(){
		modelBaked = true;
	}
	
	@Override
	public boolean isOp(EntityPlayer player){
		if(player.world.isRemote){
			return player==Minecraft.getMinecraft().player ? Minecraft.getMinecraft().player.getPermissionLevel()>=1 : false;
		}else return super.isOp(player);
	}
	
	@Override
	public void placeParticle(ParticlePlacer particle){
		particle.placeParticle();
	}
}
