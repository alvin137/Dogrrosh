package com.tictim.utilib.event;

import java.util.List;
import java.util.function.Consumer;
import com.google.common.collect.Lists;
import com.tictim.utilib.TUtilib;
import com.tictim.utilib.net.PlayerLogInMessage;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;

public final class Events{
	private Events(){}
	
	private static final List<Consumer<World>> onRemote = Lists.newArrayList(), onNotRemote = Lists.newArrayList();
	
	public static void addTickingTask(Consumer<World> task, boolean tickOnRemote, boolean tickOnNotRemote){
		if(tickOnRemote) onRemote.add(task);
		if(tickOnNotRemote) onNotRemote.add(task);
	}
	
	@SubscribeEvent
	public static void onPlayerLogin(PlayerLoggedInEvent event){
		TUtilib.CORE_NET.sendTo(new PlayerLogInMessage(), (EntityPlayerMP)event.player);
	}
	
	@SubscribeEvent
	public static void attachCapability(AttachCapabilitiesEvent<World> event){
		event.getObject().addWeatherEffect(new TickManager(event.getObject()));
	}
	
	private static class TickManager extends Entity{
		public TickManager(World world){
			super(world);
			this.forceSpawn = true;
		}
		
		@Override
		public void onUpdate(){
			for(Consumer<World> e : this.world.isRemote ? onRemote : onNotRemote){
				e.accept(this.world);
			}
		}
		
		@Override
		public boolean shouldRenderInPass(int pass){
			return false;
		}
		
		@Override
		public void onKillCommand(){}
		
		@Override
		protected void entityInit(){}
		
		@Override
		protected void readEntityFromNBT(NBTTagCompound compound){}
		
		@Override
		protected void writeEntityToNBT(NBTTagCompound compound){}
	}
}
