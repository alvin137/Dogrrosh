package com.tictim.utilib.config;

import javax.annotation.concurrent.Immutable;

@Immutable
public abstract class ConfigValueRange<T>{
	private ConfigValueRange(){}
	
	public static final ConfigValueRange<Boolean> TRUE = new BooleanRange(true);
	public static final ConfigValueRange<Boolean> FALSE = new BooleanRange(false);
	
	public static final class BooleanRange extends ConfigValueRange<Boolean>{
		private final boolean defaultValue;
		
		public BooleanRange(boolean defaultValue){
			this.defaultValue = defaultValue;
		}
		
		@Override
		public Boolean getDefault(){
			return defaultValue;
		}
	}
	
	public static final class IntRange extends ConfigValueRange<Integer>{
		private final int defaultValue, maxValue, minValue;
		
		public IntRange(int defaultValue, int maxValue, int minValue){
			this.defaultValue = defaultValue;
			this.maxValue = Math.max(maxValue, minValue);
			this.minValue = Math.min(maxValue, minValue);
		}
		
		@Override
		public Integer getMax(){
			return maxValue;
		}
		
		@Override
		public Integer getMin(){
			return minValue;
		}
		
		@Override
		public Integer getDefault(){
			return defaultValue;
		}
	}
	
	public static final class DoubleRange extends ConfigValueRange<Double>{
		private final double defaultValue, maxValue, minValue;
		
		public DoubleRange(double defaultValue, double maxValue, double minValue){
			this.defaultValue = defaultValue;
			this.maxValue = Math.max(maxValue, minValue);
			this.minValue = Math.min(maxValue, minValue);
		}
		
		@Override
		public Double getMax(){
			return maxValue;
		}
		
		@Override
		public Double getMin(){
			return minValue;
		}
		
		@Override
		public Double getDefault(){
			return defaultValue;
		}
	}
	
	public static final class StringRange extends ConfigValueRange<String>{
		private final String defaultValue;
		
		public StringRange(String defaultValue){
			this.defaultValue = defaultValue;
		}
		
		@Override
		public String getDefault(){
			return defaultValue;
		}
	}
	
	public int intMax(){
		return Integer.MAX_VALUE;
	}
	
	public int intMin(){
		return 0;
	}
	
	public double doubleMax(){
		return Double.MAX_VALUE;
	}
	
	public double doubleMin(){
		return 0.0;
	}
	
	public abstract T getDefault();
	
	public T getMax(){
		throw new RuntimeException();
	}
	
	public T getMin(){
		throw new RuntimeException();
	}
}
