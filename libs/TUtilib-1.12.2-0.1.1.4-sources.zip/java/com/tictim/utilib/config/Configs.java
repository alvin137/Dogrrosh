package com.tictim.utilib.config;

import java.io.File;
import java.util.Collection;
import java.util.List;
import javax.annotation.Nullable;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.tictim.utilib.config.ConfigValueRange.BooleanRange;
import com.tictim.utilib.config.ConfigValueRange.DoubleRange;
import com.tictim.utilib.config.ConfigValueRange.IntRange;
import com.tictim.utilib.config.ConfigValueRange.StringRange;
import net.minecraftforge.common.config.Configuration;

public final class Configs{
	private Configs(){}
	
	public static final ConfigValueRange<Boolean> TRUE = new BooleanRange(true);
	public static final ConfigValueRange<Boolean> FALSE = new BooleanRange(false);
	
	public static final Multimap<String, Config> SYNCABLE_LOADED_CONFIGS = HashMultimap.<String, Config>create();
	
	public static final Config<Boolean> boolConfig(@Nullable Collection<Config> toAdd, String category, String name, String comment, boolean defaultValue){
		SimpleConfig<Boolean> returns = new SimpleConfig<Boolean>(category, name, comment, ConfigType.BOOLEAN, defaultValue ? TRUE : FALSE);
		if(toAdd!=null) toAdd.add(returns);
		return returns;
	}
	
	public static final Config<Integer> intConfig(@Nullable Collection<Config> toAdd, String category, String name, String comment, int defaultValue, int maxValue, int minValue){
		SimpleConfig<Integer> returns = new SimpleConfig<Integer>(category, name, comment, ConfigType.INTEGER, new IntRange(defaultValue, maxValue, minValue));
		if(toAdd!=null) toAdd.add(returns);
		return returns;
	}
	
	public static final Config<Double> doubleConfig(@Nullable Collection<Config> toAdd, String category, String name, String comment, double defaultValue, double maxValue, double minValue){
		SimpleConfig<Double> returns = new SimpleConfig<Double>(category, name, comment, ConfigType.DOUBLE, new DoubleRange(defaultValue, maxValue, minValue));
		if(toAdd!=null) toAdd.add(returns);
		return returns;
	}
	
	public static final Config<String> stringConfig(@Nullable Collection<Config> toAdd, String category, String name, String comment, String defaultValue){
		SimpleConfig<String> returns = new SimpleConfig<String>(category, name, comment, ConfigType.STRING, new StringRange(defaultValue));
		if(toAdd!=null) toAdd.add(returns);
		return returns;
	}
	
	public static void loadConfig(String configurationDirectory, String filename, List<Config> configs){
		Configuration config = new Configuration(new File(configurationDirectory+"/tictim/"+filename+".cfg"));
		for(int i = 0; i<configs.size(); i++){
			Config c = configs.get(i);
			c.initValue(config, i);
			if(c.haveToSync()) SYNCABLE_LOADED_CONFIGS.put(filename, c);
		}
		config.save();
	}
}
