package com.tictim.utilib.config;

import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraftforge.common.config.Configuration;

public interface Config<T>extends Comparable<Config<T>>, Supplier<T>{
	String getCategory();
	String getName();
	String getComment();
	ConfigType<T> getType();
	ConfigValueRange<T> getConfigValueRange();
	
	/** INTERNAL. DO NOT USE */
	void setValue(T newValue);
	/** INTERNAL. DO NOT USE */
	void syncValue(T newValue);
	
	/** INTERNAL. DO NOT USE */
	boolean setServerSynced(boolean newValue);
	boolean isServerSynced();
	
	default String getIdentificationString(){
		return getType().getTypeString()+":"+getCategory()+"#"+getName();
	}
	
	/** INTERNAL. DO NOT USE */
	default void initValue(Configuration cfg, int ordinal){
		this.setValue(this.getType().getConfigValue(cfg, ordinal, this));
	}
	
	default boolean haveToSync(){
		return false;
	}
	
	Config<T> setHaveToSync(@Nullable Consumer<T> eventHandler);
	
	/** INTERNAL. DO NOT USE */
	default void onSync(){}
	
	default int compareTo(Config<T> o){
		return this.getName().compareTo(o.getName());
	}
}
