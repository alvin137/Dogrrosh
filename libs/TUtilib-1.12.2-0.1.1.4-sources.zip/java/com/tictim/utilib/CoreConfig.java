package com.tictim.utilib;

import java.util.List;
import com.google.common.collect.Lists;
import com.tictim.utilib.config.Config;
import com.tictim.utilib.config.Configs;

public final class CoreConfig{
	private CoreConfig(){}
	
	public static final List<Config> list = Lists.newArrayList();
	
	public static final Config<Boolean> DEBUG_CONFIG = Configs.boolConfig(list, "master", "DEBUG_CONFIG", "", false);
	public static final Config<Boolean> CREATE_ALL_CREATIVE_TABS = Configs.boolConfig(list, "master", "CREATE_ALL_CREATIVE_TABS", "", false);
}
