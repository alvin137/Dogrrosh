package com.tictim.utilib.util;

import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.INBTSerializable;

public final class EntityHolder implements INBTSerializable<NBTTagCompound>, Cloneable{
	@Nullable
	private WorldServer world;
	@Nullable
	private Entity entity;
	@Nullable
	private UUID entityId;
	
	public EntityHolder(){}
	
	public EntityHolder(@Nullable Entity e){
		if(e!=null) set(e);
	}
	
	public EntityHolder(@Nullable World w, @Nullable UUID uid){
		updateWorld(w);
		entityId = uid;
	}
	
	public void set(@Nullable Entity entity){
		this.entity = entity;
		this.entityId = entity==null ? null : entity.getUniqueID();
		updateWorld(entity!=null ? entity.world : null);
	}
	
	public void updateWorld(World updatedWorld){
		WorldServer w = updatedWorld instanceof WorldServer ? (WorldServer)updatedWorld : null;
		if(world!=w) entity = null;
		world = w;
	}
	
	@Nullable
	public Entity get(World updatedWorld){
		updateWorld(updatedWorld);
		return get();
	}
	
	@Nullable
	public Entity get(){
		if(this.entity==null&&this.entityId!=null&&world!=null){
			this.entity = world.getEntityFromUuid(this.entityId);
			if(this.entity==null) this.entityId = null;
		}
		return this.entity;
	}
	
	@Nullable
	public UUID getEntityUUID(){
		return this.entityId;
	}
	
	@Override
	public NBTTagCompound serializeNBT(){
		NBTTagCompound nbt = new NBTTagCompound();
		if(entityId!=null){
			nbt.setUniqueId("id", entityId);
		}
		return nbt;
	}
	
	@Override
	public void deserializeNBT(NBTTagCompound nbt){
		if(nbt.hasUniqueId("id")){
			this.entityId = nbt.getUniqueId("id");
		}
	}
	
	@Override
	public String toString(){
		Entity ent = get();
		return ent!=null ? ent+" ("+entityId+")" : I18n.translateToLocal("i.no_entity");
	}
	
	@Override
	public boolean equals(Object o){
		if(o==this) return true;
		else if(o==null||o.getClass()!=EntityHolder.class) return false;
		else{
			EntityHolder o2 = (EntityHolder)o;
			return Objects.equals(o2.entityId, entityId);
		}
	}
	
	@Override
	public EntityHolder clone(){
		return new EntityHolder(world, entityId);
	}
}
