package com.tictim.utilib.util;

import java.util.Random;
import javax.annotation.Nullable;
import javax.vecmath.Vector3d;
import org.apache.commons.lang3.ArrayUtils;
import com.tictim.utilib.TUtilib;
import com.tictim.utilib.nbt.NBTTypes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ParticlePlacer implements INBTSerializable<NBTTagCompound>{
	private int particleId;
	private int particleAmount = 1, color = 0xFFFFFF;
	private Vector3d pos = new Vector3d();
	private Vector3d spread = new Vector3d();
	private Vector3d speed = new Vector3d();
	private Vector3d speedSpread = new Vector3d();
	private int[] param = ArrayUtils.EMPTY_INT_ARRAY;
	
	@Nullable
	private ParticlePlacer next;
	
	public ParticlePlacer(EnumParticleTypes particle){
		this.particleId = particle.getParticleID();
	}
	
	public ParticlePlacer(NBTTagCompound nbt){
		deserializeNBT(nbt);
	}
	
	@Override
	public NBTTagCompound serializeNBT(){
		NBTTagCompound nbt = new NBTTagCompound();
		nbt.setInteger("id", particleId);
		nbt.setInteger("amount", particleAmount);
		nbt.setInteger("color", color);
		if(!pos.equals(Vec3d.ZERO)){
			nbt.setDouble("pos.x", pos.x);
			nbt.setDouble("pos.y", pos.y);
			nbt.setDouble("pos.z", pos.z);
		}
		if(!spread.equals(Vec3d.ZERO)){
			nbt.setDouble("spread.x", spread.x);
			nbt.setDouble("spread.y", spread.y);
			nbt.setDouble("spread.z", spread.z);
		}
		if(!speed.equals(Vec3d.ZERO)){
			nbt.setDouble("speed.x", speed.x);
			nbt.setDouble("speed.y", speed.y);
			nbt.setDouble("speed.z", speed.z);
		}
		if(!speedSpread.equals(Vec3d.ZERO)){
			nbt.setDouble("speedSpread.x", speedSpread.x);
			nbt.setDouble("speedSpread.y", speedSpread.y);
			nbt.setDouble("speedSpread.z", speedSpread.z);
		}
		nbt.setIntArray("par", param);
		if(this.next!=null) nbt.setTag("next", next.serializeNBT());
		return nbt;
	}
	
	@Override
	public void deserializeNBT(NBTTagCompound nbt){
		this.particleId = nbt.getInteger("id");
		this.particleAmount = nbt.getInteger("amount");
		this.color = nbt.getInteger("color");
		this.pos.set(nbt.getDouble("pos.x"), nbt.getDouble("pos.y"), nbt.getDouble("pos.z"));
		this.spread.set(nbt.getDouble("spread.x"), nbt.getDouble("spread.y"), nbt.getDouble("spread.z"));
		this.speed.set(nbt.getDouble("speed.x"), nbt.getDouble("speed.y"), nbt.getDouble("speed.z"));
		this.speedSpread.set(nbt.getDouble("speedSpread.x"), nbt.getDouble("speedSpread.y"), nbt.getDouble("speedSpread.z"));
		this.param = nbt.getIntArray("par");
		if(nbt.hasKey("next", NBTTypes.COMPOUND)) this.next = new ParticlePlacer(nbt.getCompoundTag("next"));
		else this.next = null;
	}
	
	public ParticlePlacer amount(int particleAmount){
		if(particleAmount<=0) throw new IllegalArgumentException(String.valueOf(particleAmount));
		this.particleAmount = particleAmount;
		return this;
	}
	
	public ParticlePlacer color(int particleAmount){
		this.color = 0xFFFFFF&particleAmount;
		return this;
	}
	
	public ParticlePlacer pos(double x, double y, double z){
		this.pos.set(x, y, z);
		return this;
	}
	
	public ParticlePlacer pos(Vec3d vec){
		return pos(vec.x, vec.y, vec.z);
	}
	
	public ParticlePlacer pos(Entity ent, boolean useEyePos){
		return pos(ent.posX, useEyePos ? TUtils.getEyePosY(ent) : ent.posY, ent.posZ);
	}
	
	public ParticlePlacer spread(double x, double y, double z){
		this.spread.set(x, y, z);
		return this;
	}
	
	public ParticlePlacer spread(Vec3d vec){
		return spread(vec.x, vec.y, vec.z);
	}
	
	public ParticlePlacer spread(Entity ent, boolean useEyePos){
		return spread(ent.posX, useEyePos ? TUtils.getEyePosY(ent) : ent.posY, ent.posZ);
	}
	
	public ParticlePlacer speed(double x, double y, double z){
		this.speed.set(x, y, z);
		return this;
	}
	
	public ParticlePlacer speed(Vec3d vec){
		return speed(vec.x, vec.y, vec.z);
	}
	
	public ParticlePlacer speed(Entity ent, boolean useEyePos){
		return speed(ent.posX, useEyePos ? TUtils.getEyePosY(ent) : ent.posY, ent.posZ);
	}
	
	public ParticlePlacer speedSpread(double x, double y, double z){
		this.speedSpread.set(x, y, z);
		return this;
	}
	
	public ParticlePlacer speedSpread(Vec3d vec){
		return speedSpread(vec.x, vec.y, vec.z);
	}
	
	public ParticlePlacer speedSpread(Entity ent, boolean useEyePos){
		return speedSpread(ent.posX, useEyePos ? TUtils.getEyePosY(ent) : ent.posY, ent.posZ);
	}
	
	public ParticlePlacer param(int... par){
		this.param = par;
		return this;
	}
	
	public void tryPlaceParticle(){
		TUtilib.proxy.placeParticle(this);
	}
	
	@SideOnly(Side.CLIENT)
	public void placeParticle(){
		placeParticle(Minecraft.getMinecraft().effectRenderer);
	}
	
	@SideOnly(Side.CLIENT)
	private void placeParticle(ParticleManager manager){
		for(int i = 0; i<particleAmount; i++){
			Random rng = TUtils.RNG;
			
			double x = pos.x+spread.x*rng.nextGaussian();
			double y = pos.y+spread.y*rng.nextGaussian();
			double z = pos.z+spread.z*rng.nextGaussian();
			double sx = speed.x+speedSpread.x*rng.nextGaussian();
			double sy = speed.y+speedSpread.y*rng.nextGaussian();
			double sz = speed.z+speedSpread.z*rng.nextGaussian();
			
			Particle p = manager.spawnEffectParticle(particleId, x, y, z, sx, sy, sz, param);
			if(p!=null){
				float r = (color>>16&255)/255f, g = (color>>8&255)/255f, b = (color&255)/255f,
						chroma = 0.75F+rng.nextFloat()*0.25F;
				p.setRBGColorF(r*chroma, g*chroma, b*chroma);
				p.multiplyVelocity((float)sy);
			}
		}
		if(next!=null) next.placeParticle(manager);
	}
}
