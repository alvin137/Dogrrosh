package com.tictim.utilib.util;

import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.translation.I18n;
import net.minecraftforge.common.util.INBTSerializable;

public final class Owner implements INBTSerializable<NBTTagCompound>, Comparable<Owner>, Cloneable{
	private String ownerName = "";
	@Nullable
	private UUID ownerId = null;
	private boolean isPublic;
	
	public Owner(){}
	
	public Owner(@Nullable EntityPlayer player){
		if(player!=null) setOwner(player);
	}
	
	public Owner(@Nullable UUID owner, @Nullable String name){
		setOwner(owner, name);
	}
	
	public Owner(NBTTagCompound nbt){
		deserializeNBT(nbt);
	}
	
	public boolean isOwnerEquals(EntityPlayer player){
		return ownerId==null||ownerId.equals(EntityPlayer.getUUID(player.getGameProfile()));
	}
	
	public void setOwner(@Nullable EntityPlayer player){
		setOwner(player==null ? null : EntityPlayer.getUUID(player.getGameProfile()), player==null ? "" : player.getName());
	}
	
	public void setOwner(@Nullable UUID owner, @Nullable String name){
		if(this.ownerId==null&&owner!=null) isPublic = false;
		this.ownerId = owner;
		this.ownerName = owner==null||name==null ? "" : name;
	}
	
	public boolean hasOwner(){
		return this.ownerId!=null;
	}
	
	public boolean hasPermission(EntityPlayer player){
		return isPublic()||isOwnerEquals(player)||TUtils.isOp(player);
	}
	
	public String getOwnerName(){
		return this.ownerName;
	}
	
	@Nullable
	public UUID getOwnerUUID(){
		return this.ownerId;
	}
	
	public boolean isPublic(){
		return !hasOwner()||isPublic;
	}
	
	public void setPublic(boolean isPublic){
		this.isPublic = isPublic;
	}
	
	@Override
	public NBTTagCompound serializeNBT(){
		NBTTagCompound nbt = new NBTTagCompound();
		if(this.ownerId!=null){
			nbt.setUniqueId("owner", this.ownerId);
			nbt.setString("ownerName", this.ownerName);
		}
		if(isPublic) nbt.setBoolean("isPublic", true);
		return nbt;
	}
	
	@Override
	public void deserializeNBT(NBTTagCompound nbt){
		if(nbt.hasUniqueId("owner")){
			this.ownerId = nbt.getUniqueId("owner");
			this.ownerName = nbt.getString("ownerName");
		}else{
			this.ownerId = null;
			this.ownerName = "";
		}
		isPublic = nbt.getBoolean("isPublic");
	}
	
	@Override
	public String toString(){
		return this.hasOwner() ? this.ownerName+" ("+this.ownerId+")" : I18n.translateToLocal("i.no_owner");
	}
	
	@Override
	public boolean equals(Object o){
		if(o==this) return true;
		else if(o==null||o.getClass()!=Owner.class) return false;
		else{
			Owner o2 = (Owner)o;
			return Objects.equals(o2.ownerId, ownerId)&&isPublic==o2.isPublic;
		}
	}
	
	@Override
	public int compareTo(Owner o){
		// #1 hasOwner, true first
		int i = Boolean.compare(hasOwner(), o.hasOwner());
		if(i!=0) return -i;
		else if(!hasOwner()) return 0;
		// #2 owner name
		i = getOwnerName().compareTo(o.getOwnerName());
		if(i!=0) return i;
		// #3 uuid
		return getOwnerUUID().compareTo(o.getOwnerUUID());
	}
	
	@Override
	public Owner clone(){
		return new Owner(this.ownerId, this.ownerName);
	}
}
