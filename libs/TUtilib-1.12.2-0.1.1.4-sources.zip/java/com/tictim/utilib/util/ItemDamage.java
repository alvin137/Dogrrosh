package com.tictim.utilib.util;

import java.util.Iterator;
import java.util.List;
import java.util.stream.IntStream;
import javax.annotation.Nullable;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Validate;
import com.google.common.collect.Lists;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

public final class ItemDamage{
	private final List<DamageKey> lists = Lists.newArrayList();
	
	private final Object instance;
	
	public ItemDamage(Object instance){
		if(instance instanceof Item){
			((Item)instance).setHasSubtypes(true);
		}
		this.instance = instance;
	}
	
	public <T> DamageKey<T> addCase(T... enums){
		if(enums.length<=0) throw new IllegalArgumentException("enumValues.length is 0");
		else{
			Validate.noNullElements(enums);
			int var = getVariations();
			DamageKey<T> d = new DamageKey(var, enums);
			lists.add(d);
			if(var*enums.length>=OreDictionary.WILDCARD_VALUE){
				TUtils.LOGGER.error("Too much enums! Maximum damage value is greater than stack's damage value limit. Things may not work well.");
			}
			return d;
		}
	}
	
	public int getVariations(){
		return lists.stream().mapToInt(d -> d.enums.length).reduce(1, (a, b) -> a*b);
	}
	
	public Builder build(){
		return new Builder();
	}
	
	public Builder build(int value){
		return new Builder(value);
	}
	
	public StackBuilder stackBuild(){
		return new StackBuilder();
	}
	
	public StackBuilder stackBuild(int value){
		return new StackBuilder(value);
	}
	
	public Variations getVar(DamageKey... vars){
		return new Variations(vars);
	}
	
	public Variations getFullVar(){
		DamageKey[] keys = lists.toArray(new DamageKey[lists.size()]);
		ArrayUtils.reverse(keys);
		return new Variations(keys);
	}
	
	public class DamageKey<T>{
		private final T[] enums;
		private final int lastVar;
		
		private DamageKey(int lastVar, T... enums){
			this.enums = enums;
			this.lastVar = lastVar;
		}
		
		@Nullable
		public T toEnum(ItemStack stack){
			if(stack.getItem()==null) return null;
			else return toEnum(stack.getItemDamage());
		}
		
		@Nullable
		public T toEnum(int stackDamage){
			return enums[(stackDamage/lastVar)%enums.length];
		}
		
		public int toDamage(Object e){
			int idx = ArrayUtils.indexOf(enums, e);
			if(idx==ArrayUtils.INDEX_NOT_FOUND) throw new RuntimeException("enums is not containing element "+e);
			else return idx*lastVar;
		}
		
		public boolean isOriginEquals(ItemDamage origin){
			return origin==ItemDamage.this;
		}
		
		public int swapValue(int dmg, Object value){
			return dmg-(dmg%(enums.length*lastVar))+toDamage(value);
		}
	}
	
	public class Builder{
		protected int damage;
		
		public Builder(){}
		
		public Builder(int dmg){
			this.damage = dmg;
		}
		
		public Builder with(DamageKey<?> key, Object value){
			if(!key.isOriginEquals(ItemDamage.this)) throw new IllegalArgumentException("Invalid DamageKey");
			else{
				damage = key.swapValue(damage, value);
				return this;
			}
		}
		
		public int get(){
			return this.damage;
		}
		
		public ItemStack toStack(Item item){
			return new ItemStack(item, 1, damage);
		}
		
		public ItemStack toStack(Item item, int amount){
			return new ItemStack(item, amount, damage);
		}
	}
	
	public class StackBuilder extends Builder{
		public StackBuilder(){
			if(!(ItemDamage.this.instance instanceof Item))
				throw new RuntimeException("Cannot create StackBuilder from non-item ItemDamage instance");
		}
		
		public StackBuilder(int dmg){
			this();
			this.damage = dmg;
		}
		
		public ItemStack toStack(){
			return new ItemStack((Item)ItemDamage.this.instance, 1, damage);
		}
		
		public ItemStack toStack(int amount){
			return new ItemStack((Item)ItemDamage.this.instance, amount, damage);
		}
	}
	
	public class Variations implements Iterable<Integer>{
		private final List<Integer> damageList = Lists.newArrayList();
		
		public Variations(DamageKey... vars){
			for(DamageKey k : vars){
				if(!k.isOriginEquals(ItemDamage.this)) throw new IllegalArgumentException("Invalid DamageKey");
			}
			addVariation(vars, 0, 0);
		}
		
		private void addVariation(DamageKey[] vars, int varIdx, int currentDamage){
			if(vars.length>varIdx){
				DamageKey var = vars[varIdx];
				for(int i = 0; i<var.enums.length; i++, currentDamage += var.lastVar){
					addVariation(vars, varIdx+1, currentDamage);
				}
			}else damageList.add(currentDamage);
		}
		
		public int numberOfVariations(){
			return this.damageList.size();
		}
		
		@Override
		public Iterator<Integer> iterator(){
			return damageList.iterator();
		}
		
		public IntStream stream(){
			return damageList.stream().mapToInt(i -> i);
		}
	}
}
