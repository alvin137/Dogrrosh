package com.tictim.utilib.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import com.google.common.collect.Maps;

public class SimpleSetTable<E>extends AbstractSetTable<E>{
	private final Map<E, Integer> rollMap = Maps.newHashMap();
	
	public boolean add(E e, int roll){
		if(roll<0) throw new IllegalArgumentException(String.valueOf(roll));
		if(add(e)){
			if(roll!=1) rollMap.put(e, roll);
			return true;
		}else return false;
	}
	
	public boolean setRoll(E e, int roll){
		if(roll<0) throw new IllegalArgumentException(String.valueOf(roll));
		if(this.contains(e)){
			if(roll!=1) rollMap.put(e, roll);
			else rollMap.remove(roll);
			return true;
		}else return false;
	}
	
	@Override
	public void clear(){
		this.sets.clear();
		update();
	}
	
	@Override
	public boolean remove(Object o){
		if(this.sets.remove(o)){
			update();
			return true;
		}else return false;
	}
	
	@Override
	public boolean removeAll(Collection<?> c){
		if(this.sets.removeAll(c)){
			update();
			return true;
		}else return false;
	}
	
	@Override
	public boolean retainAll(Collection<?> c){
		if(this.sets.retainAll(c)){
			update();
			return true;
		}else return false;
	}
	
	private void update(){
		Iterator<Entry<E, Integer>> it = rollMap.entrySet().iterator();
		while(it.hasNext()){
			Entry<E, Integer> e = it.next();
			if(!this.sets.contains(e.getKey())) it.remove();
		}
	}
	
	@Override
	protected int getRoll(E e, @Nullable Collection<E> currentPool){
		if(currentPool!=null&&currentPool.contains(e)) return 0;
		else if(this.rollMap.containsKey(e)) return this.rollMap.get(e);
		else return 1;
	}
}
