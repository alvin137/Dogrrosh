package com.tictim.utilib.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.message.ParameterizedMessage;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.tictim.utilib.TUtilib;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.MutableBlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fml.relauncher.CoreModManager;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.oredict.OreDictionary;

public final class TUtils{
	private TUtils(){}
	
	public static final Logger LOGGER = LogManager.getLogger("TUtilib");
	public static final Random RNG = new Random(System.currentTimeMillis());
	private static final boolean isDevEnv;
	
	public static final String KEY_BLOCK_ENTITY_TAG = "BlockEntityTag";
	
	public static final DecimalFormat FORMAT = ItemStack.DECIMALFORMAT;
	public static final DecimalFormat FORMAT_EXT = new DecimalFormat("#.######");
	
	static{
		boolean c = false;
		try{
			Field field = CoreModManager.class.getDeclaredField("deobfuscatedEnvironment");
			field.setAccessible(true);
			c = field.getBoolean(null);
		}catch(Exception e){
			e.printStackTrace();
		}
		isDevEnv = c;
	}
	
	// CommonUtils
	
	public static <T> T getRandomIndex(T[] array, Random rng){
		return array[rng.nextInt(array.length)];
	}
	
	public static boolean roll(Random rng, double chance){
		return rng.nextDouble()<chance;
	}
	
	public static boolean roll(double chance){
		return Math.random()<chance;
	}
	
	public static boolean isPlayerCreativeOrSpectator(EntityPlayer p){
		return p.capabilities.isCreativeMode||p.isSpectator();
	}
	
	public static boolean canParseToInteger(String str, boolean allowNegative){
		if(str.length()>0){
			int i = 0;
			if(allowNegative){
				char c = str.charAt(i);
				if(((c=='-'||c=='+')&&str.length()>1)||Character.isDigit(c)) i++;
				else return false;
			}
			for(; i<str.length(); i++)
				if(!Character.isDigit(str.charAt(i))) return false;
			return true;
		}else return false;
	}
	
	public static double getEyePosY(Entity e){
		return e.posY+e.getEyeHeight();
	}
	
	/** @see Entity#getPositionEyes(float) */
	public static Vec3d getEyeVector(Entity e){
		return new Vec3d(e.posX, getEyePosY(e), e.posZ);
	}
	
	public static final double RAD_1DEG = Math.PI/180.0;
	public static final double DEG_1RAD = 180/Math.PI;
	
	@Nullable
	public static RayTraceResult rayTrace(World world, Entity ent, double endLength, boolean useLiquids){
		return rayTrace(world, getEyeVector(ent), ent.rotationPitch, ent.rotationYaw, endLength, useLiquids);
	}
	
	@Nullable
	public static RayTraceResult rayTrace(World world, Vec3d start, double pitch, double yaw, double endLength, boolean useLiquids){
		double f4 = (-Math.cos(pitch*RAD_1DEG))*endLength;
		Vec3d end = start.addVector(Math.sin(-yaw*RAD_1DEG-Math.PI)*f4, Math.sin(-pitch*RAD_1DEG)*endLength, Math.cos(-yaw*RAD_1DEG-Math.PI)*f4);
		return world.rayTraceBlocks(start, end, useLiquids, !useLiquids, false);
	}
	
	public static Vec3d getEndPoint(World world, Entity ent, double endLength, boolean useLiquids){
		return getEndPoint(world, getEyeVector(ent), ent.rotationPitch, ent.rotationYaw, endLength, useLiquids);
	}
	
	public static Vec3d getEndPoint(World world, Vec3d start, double pitch, double yaw, double endLength, boolean useLiquids){
		double f4 = (-Math.cos(pitch*RAD_1DEG))*endLength;
		Vec3d end = start.addVector(Math.sin(-yaw*RAD_1DEG-Math.PI)*f4, Math.sin(-pitch*RAD_1DEG)*endLength, Math.cos(-yaw*RAD_1DEG-Math.PI)*f4);
		RayTraceResult result = world.rayTraceBlocks(start, end, useLiquids, !useLiquids, false);
		return result!=null ? result.hitVec : end;
	}
	
	public static final boolean isDevEnv(){
		return isDevEnv;
	}
	
	private static final MutableBlockPos POS = new MutableBlockPos();
	
	/**
	 * Note: This method uses {@link MutableBlockPos}.
	 * @see #iterateNearbyBlocks(World, double, double, double, int, int, int, Consumer)
	 */
	public static void iterateNearbyBlocks(Entity entity, int xzRad, int yDownOffset, int yHeight, Consumer<BlockPos> todo){
		iterateNearbyBlocks(entity.world, entity.posX, entity.posY, entity.posZ, xzRad, yDownOffset, yHeight, todo);
	}
	
	/** Note: This method uses {@link MutableBlockPos}. */
	public static void iterateNearbyBlocks(World world, double posX, double posY, double posZ, int xzRad, int yDownOffset, int yHeight, Consumer<BlockPos> todo){
		final int _x = MathHelper.floor(posX);
		final int _y = MathHelper.floor(posY+0.5);
		final int _z = MathHelper.floor(posZ);
		for(int y = _y-yDownOffset; y<_y-yDownOffset+yHeight; y++){
			if(y<0){
				if(_y+yHeight>0){
					y = 0;
				}else return;
			}else if(y>=256) return;
			for(int x = _x-(xzRad/2); x<_x+xzRad; x++){
				for(int z = _z-(xzRad/2); z<_z+xzRad; z++){
					todo.accept(POS.setPos(x, y, z));
				}
			}
		}
	}
	
	@Nullable
	public static <T extends TileEntity> T getTE(IBlockAccess world, BlockPos pos){
		T instance;
		try{
			instance = (T)(world instanceof ChunkCache ? ((ChunkCache)world).getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK) : world.getTileEntity(pos));
		}catch(ClassCastException e){
			instance = null;
		}
		return instance;
	}
	
	@Nullable
	public static <T> T getTECap(IBlockAccess world, BlockPos pos, Capability<T> cap, @Nullable EnumFacing facing){
		TileEntity te = world instanceof ChunkCache ? ((ChunkCache)world).getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK) : world.getTileEntity(pos);
		if(te!=null){
			T c = te.getCapability(cap, facing);
			return c;
		}
		return null;
	}
	
	// ClientUtils
	
	@SideOnly(Side.CLIENT)
	public static final boolean isSneakKeyDown(){
		return GameSettings.isKeyDown(Minecraft.getMinecraft().gameSettings.keyBindSneak);
	}
	
	@SideOnly(Side.CLIENT)
	public static final boolean isSprintKeyDown(){
		return GameSettings.isKeyDown(Minecraft.getMinecraft().gameSettings.keyBindSprint);
	}
	
	/**
	 * <b>Dev only</b><br>
	 * Development Environment�� �ƴ� ȯ�濡�� ȣ���ϰ� �Ǹ� RuntimeException�� ����ŵ�ϴ�.
	 */
	@SideOnly(Side.CLIENT)
	public static void sortLang(String modid, String fileName){
		if(!isDevEnv()) throw new RuntimeException("sortLang(...) in non-dev env");
		File file = new File(new File(".").getAbsoluteFile().getParentFile().getParentFile(), "/src/main/resources/assets/"+modid+"/lang/"+fileName+".lang");
		if(!file.exists()||!file.isFile()){
			TUtils.LOGGER.error("root file /src/main/resources/assets/"+modid+"/lang/"+fileName+".lang does not exist");
		}else{
			try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))){
				Set<String> set = Sets.newTreeSet();
				while(true){
					String str = reader.readLine();
					if(str==null) break;
					else if(str.contains("=")) set.add(str);
				}
				reader.close();
				if(!file.delete()){
					TUtils.LOGGER.error("cannot delete file "+file.getAbsolutePath());
					return;
				}else{
					if(file.createNewFile()){
						Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
						String c = null;
						for(String s : set){
							String cache = s.substring(0, s.indexOf("="));
							if(cache.contains(".")) cache = s.substring(0, s.indexOf("."));
							if(!cache.equals(c)){
								c = cache;
								TUtils.LOGGER.info("new lang set is %s", c);
								writer.write("\n");
							}
							writer.write(s+"\n");
						}
						writer.close();
					}else{
						TUtils.LOGGER.error("cannot re-create file "+file.getAbsolutePath());
						return;
					}
				}
			}catch(IOException e){
				TUtils.LOGGER.error(e);
			}
		}
	}
	
	// ItemUtils
	
	public static boolean hasOreDict(ItemStack stack, String oreDict){
		return !stack.isEmpty()&&OreDictionary.doesOreNameExist(oreDict)&&OreDictionary.getOres(oreDict).stream().anyMatch(t -> OreDictionary.itemMatches(stack, t, false));
	}
	
	public static ItemStack getCorrectItemStack(EntityPlayer player, Predicate<ItemStack> comparator){
		ItemStack s = player.getHeldItem(EnumHand.OFF_HAND);
		if(!s.isEmpty()&&comparator.test(s)){
			return s;
		}else{
			s = player.getHeldItem(EnumHand.MAIN_HAND);
			if(!s.isEmpty()&&comparator.test(s)){
				return s;
			}else return getCorrectItemStack(player.inventory, comparator);
		}
	}
	
	public static ItemStack getCorrectItemStack(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(!stack.isEmpty()&&comparator.test(stack)) return stack;
		}
		return ItemStack.EMPTY;
	}
	
	public static boolean hasItemStack(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(!stack.isEmpty()&&comparator.test(stack)) return true;
		}
		return false;
	}
	
	/** @Deprecated see {@link ItemHandlerHelper#giveItemToPlayer(EntityPlayer, ItemStack)} */
	public static void giveStackToPlayer(EntityPlayer player, ItemStack stack){
		/*
		if(!player.inventory.addItemStackToInventory(stack))//try to give ItemStack in inventory
			InventoryHelper.spawnItemStack(player.world, player.posX, player.posY, player.posZ, stack); //spawn EntityItem in world
		*/
		ItemHandlerHelper.giveItemToPlayer(player, stack);
	}
	
	public static void changeCorrectItemStack(IInventory inventory, Predicate<ItemStack> comparator, Function<ItemStack, ItemStack> function){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(comparator.test(stack)) inventory.setInventorySlotContents(i, function.apply(stack));
		}
	}
	
	public static final int SLOT_NOT_FOUND = -1;
	
	public static int getCorrectStackSlot(IInventory inventory, Predicate<ItemStack> comparator){
		for(int i = 0; i<inventory.getSizeInventory(); ++i){
			ItemStack stack = inventory.getStackInSlot(i);
			if(comparator.test(stack)) return i;
		}
		return SLOT_NOT_FOUND;
	}
	
	// StringUtils
	
	public static UUID toUuid(String str){
		return UUID.nameUUIDFromBytes(str.getBytes(StandardCharsets.UTF_8));
	}
	
	public static String toUuidString(String str){
		return UUID.nameUUIDFromBytes(str.getBytes(StandardCharsets.UTF_8)).toString();
	}
	
	/** @see ParameterizedMessage#format */
	public static String format(String str, Object... args){
		return ParameterizedMessage.format(str, args);
	}
	
	@SideOnly(Side.CLIENT)
	public static void addAttributeTooltip(Multimap<String, AttributeModifier> effects, List<String> tooltip){
		if(!effects.isEmpty()){
			for(Entry<String, AttributeModifier> entry : effects.entries()){
				AttributeModifier current = entry.getValue();
				double amount = current.getAmount();
				if(amount==0.0) continue;
				else tooltip.add(" "+localizeAttrib(entry.getKey(), amount, current.getOperation()));
			}
		}
	}
	
	public static String localizeAttrib(String attribName, double amount, int operation){
		return localizeAttrib(attribName, amount, operation, false, true);
	}
	
	public static String localizeAttrib(String attribName, double amount, int operation, boolean equals, boolean color){
		if(amount==0.0) equals = true;
		double per = (operation==0 ? amount : amount*100.0);
		String formatText, text = "";
		
		if(equals){
			if(color) text = TextFormatting.GRAY.toString();
			formatText = "attribute.modifier.equals."+operation;
		}else if(amount>0.0){
			if(color) text = TextFormatting.BLUE.toString();
			formatText = "attribute.modifier.plus."+operation;
		}else{
			per = -per;
			if(color) text = TextFormatting.RED.toString();
			formatText = "attribute.modifier.take."+operation;
		}
		return text+I18n.translateToLocalFormatted(formatText, (per>=0.01 ? FORMAT : FORMAT_EXT).format(per), I18n.translateToLocal("attribute.name."+attribName));
	}
	
	public static double getAttribValue(EntityLivingBase entity, IAttribute attrib){
		IAttributeInstance i = entity.getEntityAttribute(attrib);
		if(i!=null) return i.getAttributeValue();
		else return attrib.getDefaultValue();
	}
	
	private static final Map<Block, ItemBlock> storedItemBlocks = Maps.newHashMap();
	
	public static ItemBlock createItemBlock(Block b){
		if(storedItemBlocks.containsKey(b)) return storedItemBlocks.get(b);
		else{
			ItemBlock itemBlock = b instanceof ItemBlockProvider ? ((ItemBlockProvider)b).getItemBlock() : new ItemBlock(b);
			storedItemBlocks.put(b, itemBlock);
			itemBlock.setRegistryName(b.getRegistryName());
			return itemBlock;
		}
	}
	
	public static boolean isOp(EntityPlayer player){
		return TUtilib.proxy.isOp(player);
	}
	
	@FunctionalInterface
	public static interface ItemBlockProvider{
		ItemBlock getItemBlock();
	}
}
