package com.tictim.utilib.util;

import java.util.Iterator;
import java.util.function.Function;
import javax.annotation.Nullable;

public class AbstractEnumerator<T> implements Enumerator{
	protected String divider = ", ";
	@Nullable
	protected Function<T, ?> toStringFunction;
	
	protected AbstractEnumerator(){}
	
	@Override
	public AbstractEnumerator<T> setDivider(String newDivider){
		this.divider = newDivider;
		return this;
	}
	
	public AbstractEnumerator<T> setFunction(@Nullable Function<T, ?> toStringFunction){
		this.toStringFunction = toStringFunction;
		return this;
	}
	
	public static class EnumeratorIterable<T>extends AbstractEnumerator<T>{
		private final Iterable<T> iterable;
		
		public EnumeratorIterable(Iterable<T> iterable){
			this.iterable = iterable;
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			for(T e : iterable){
				if(stb.length()>0) stb.append(this.divider);
				stb.append(toStringFunction==null ? e : toStringFunction.apply(e));
			}
			return stb.toString();
		}
	}
	
	public static class EnumeratorIterator<T>extends AbstractEnumerator<T>{
		private final Iterator<T> iterator;
		
		public EnumeratorIterator(Iterator<T> iterator){
			this.iterator = iterator;
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			while(iterator.hasNext()){
				if(stb.length()>0) stb.append(this.divider);
				stb.append(toStringFunction==null ? iterator.next() : toStringFunction.apply(iterator.next()));
			}
			return stb.toString();
		}
	}
	
	public static class EnumeratorArray<T>extends AbstractEnumerator<T>{
		private final T[] array;
		
		public EnumeratorArray(T... array){
			this.array = array;
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			for(T e : array){
				if(stb.length()>0) stb.append(this.divider);
				stb.append(toStringFunction==null ? e : toStringFunction.apply(e));
			}
			return stb.toString();
		}
	}
}
