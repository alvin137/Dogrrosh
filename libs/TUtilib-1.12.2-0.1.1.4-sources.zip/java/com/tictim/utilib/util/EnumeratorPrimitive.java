package com.tictim.utilib.util;

import java.util.function.DoubleFunction;
import java.util.function.IntFunction;
import java.util.function.LongFunction;
import javax.annotation.Nullable;

public class EnumeratorPrimitive<T> implements Enumerator{
	protected String divider = ", ";
	@Nullable
	protected T toStringFunction;
	
	@Override
	public EnumeratorPrimitive<T> setDivider(String newDivider){
		this.divider = newDivider;
		return this;
	}
	
	public EnumeratorPrimitive<T> setFunction(@Nullable T toStringFunction){
		this.toStringFunction = toStringFunction;
		return this;
	}
	
	public static class EnumeratorInt extends EnumeratorPrimitive<IntFunction>{
		private final int[] array;
		
		public EnumeratorInt(int... array){
			this.array = array;
		}
		
		public EnumeratorInt(byte... array){
			this.array = new int[array.length];
			for(int i = 0; i<array.length; i++)
				this.array[i] = array[i];
		}
		
		public EnumeratorInt(char... array){
			this.array = new int[array.length];
			for(int i = 0; i<array.length; i++)
				this.array[i] = array[i];
		}
		
		public EnumeratorInt(short... array){
			this.array = new int[array.length];
			for(int i = 0; i<array.length; i++)
				this.array[i] = array[i];
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			for(int i : array){
				if(stb.length()>0) stb.append(this.divider);
				if(toStringFunction==null) stb.append(i);
				else stb.append(toStringFunction.apply(i));
			}
			return stb.toString();
		}
	}
	
	public static class EnumeratorDouble extends EnumeratorPrimitive<DoubleFunction>{
		private final double[] array;
		
		public EnumeratorDouble(double... array){
			this.array = array;
		}
		
		public EnumeratorDouble(float... array){
			this.array = new double[array.length];
			for(int i = 0; i<array.length; i++)
				this.array[i] = array[i];
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			for(double i : array){
				if(stb.length()>0) stb.append(this.divider);
				if(toStringFunction==null) stb.append(i);
				else stb.append(toStringFunction.apply(i));
			}
			return stb.toString();
		}
	}
	
	public static class EnumeratorLong extends EnumeratorPrimitive<LongFunction>{
		private final long[] array;
		
		public EnumeratorLong(long... array){
			this.array = array;
		}
		
		@Override
		public String toString(){
			StringBuilder stb = new StringBuilder();
			for(long i : array){
				if(stb.length()>0) stb.append(this.divider);
				if(toStringFunction==null) stb.append(i);
				else stb.append(toStringFunction.apply(i));
			}
			return stb.toString();
		}
	}
}
