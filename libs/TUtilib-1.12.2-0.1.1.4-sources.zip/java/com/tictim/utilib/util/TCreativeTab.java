package com.tictim.utilib.util;

import java.util.List;
import javax.annotation.Nullable;
import com.google.common.collect.Lists;
import com.tictim.utilib.CoreConfig;
import com.tictim.utilib.TUtilib;
import com.tictim.utilib.modeled.ItemModeled;
import com.tictim.utilib.modeled.Modeled;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.registries.IForgeRegistry;

public final class TCreativeTab{
	private static final List<Item> itemsToRegister = Lists.newArrayList();
	
	public static final TCreativeTab ITEM = builder("tutilib.items").newItemForIcon(TUtilib.MODID, "icontabitems").build();
	public static final TCreativeTab TOOL = builder("tutilib.tools").newItemForIcon(TUtilib.MODID, "icontabtools").build();
	public static final TCreativeTab COMBAT = builder("tutilib.combat").newItemForIcon(TUtilib.MODID, "icontabcombat").build();
	public static final TCreativeTab BLOCK = builder("tutilib.blocks").newItemForIcon(TUtilib.MODID, "icontabblocks").build();
	public static final TCreativeTab MACHINE = builder("tutilib.machines").newItemForIcon(TUtilib.MODID, "icontabmachines").build();
	
	/** Internal */
	public static void registerAllIcons(IForgeRegistry<Item> registry){
		for(Item e : itemsToRegister)
			registry.register(e);
	}
	
	/** Internal */
	@SideOnly(Side.CLIENT)
	public static void registerAllModels(){
		for(Item e : itemsToRegister){
			if(e instanceof Modeled) ((Modeled)e).registerModels(e);
		}
	}
	
	private final String name;
	private final Item item;
	@Nullable
	private ItemStack stack;
	
	private CreativeTabs creativeTab = null;
	
	private TCreativeTab(String name, Item item, ItemStack stack, boolean needsRegister){
		this.name = name;
		this.item = item;
		this.stack = stack;
		if(needsRegister){
			this.itemsToRegister.add(item);
		}
		if(CoreConfig.CREATE_ALL_CREATIVE_TABS.get()){
			get();
		}
	}
	
	public CreativeTabs get(){
		if(creativeTab==null) creativeTab = new InternalTab(name);
		return creativeTab;
	}
	
	public ItemStack getIcon(){
		if(stack==null) this.stack = new ItemStack(item);
		return stack;
	}
	
	public static Builder builder(String name){
		return new Builder(name);
	}
	
	private final class InternalTab extends CreativeTabs{
		public InternalTab(String str){
			super(str);
		}
		
		@Override
		@SideOnly(Side.CLIENT)
		public ItemStack getTabIconItem(){
			return TCreativeTab.this.getIcon();
		}
	}
	
	public static final class Builder{
		private final String name;
		
		private Item item;
		@Nullable
		private ItemStack stack;
		private boolean needsRegister;
		
		private Builder(String name){
			this.name = name;
		}
		
		public Builder newItemForIcon(String modid, String name){
			return newItemForIcon(new ResourceLocation(modid, name));
		}
		
		public Builder newItemForIcon(ResourceLocation registryName){
			this.item = new ItemModeled().setRegistryName(registryName);
			this.stack = null;
			this.needsRegister = true;
			return this;
		}
		
		public Builder itemForIcon(Item item){
			this.item = item;
			this.stack = null;
			return this;
		}
		
		public Builder itemForIcon(ItemStack stack){
			this.stack = stack;
			this.item = stack.getItem();
			return this;
		}
		
		public TCreativeTab build(){
			if(item==null) throw new RuntimeException("Icon must not be null");
			return new TCreativeTab(name, item, stack, needsRegister);
		}
	}
}
