package com.tictim.utilib.util;

import java.util.Collection;
import javax.annotation.Nullable;
import com.tictim.utilib.util.ElementSetTable.SetElement;

public class ElementSetTable<E extends SetElement>extends AbstractSetTable<E>{
	@Override
	public int getRoll(E e, @Nullable Collection<E> currentPool){
		return e.getRoll(currentPool);
	}
	
	public static interface SetElement<E extends SetElement>{
		int getRoll();
		@Nullable
		Collection<E> getBlackList();
		@Nullable
		Collection<E> getWhiteList();
		
		default int getRoll(@Nullable Collection<E> elementSet){
			if(elementSet!=null&&isDuplicate(elementSet)) return 0;
			else return getRoll();
		}
		
		default boolean blacklistMatches(E another){
			Collection<E> l = getBlackList();
			return l!=null&&l.contains(another);
		}
		
		default boolean whitelistMatches(E another){
			return getWhiteList().contains(another);
		}
		
		default boolean isDuplicate(Collection<E> elementSet){
			return elementSet.contains(this)||elementSet.stream().anyMatch(e -> this.blacklistMatches(e)||e.blacklistMatches(this))||(getWhiteList()!=null&&!elementSet.stream().anyMatch(this::whitelistMatches));
		}
	}
}
