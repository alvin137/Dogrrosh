package com.tictim.utilib.util;

import java.util.Iterator;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.LongFunction;
import com.tictim.utilib.util.AbstractEnumerator.EnumeratorArray;
import com.tictim.utilib.util.AbstractEnumerator.EnumeratorIterable;
import com.tictim.utilib.util.AbstractEnumerator.EnumeratorIterator;
import com.tictim.utilib.util.EnumeratorPrimitive.EnumeratorDouble;
import com.tictim.utilib.util.EnumeratorPrimitive.EnumeratorInt;
import com.tictim.utilib.util.EnumeratorPrimitive.EnumeratorLong;

public interface Enumerator{
	String toString();
	Enumerator setDivider(String newDivider);
	
	static <T> AbstractEnumerator<T> enumerator(Iterable<T> iterable){
		return new EnumeratorIterable(iterable);
	}
	
	static <T> AbstractEnumerator<T> enumerator(Iterable<T> iterable, Function<T, ?> toStringFunction){
		return new EnumeratorIterable(iterable).setFunction(toStringFunction);
	}
	
	static <T> AbstractEnumerator<T> enumerator(Iterator<T> iterator){
		return new EnumeratorIterator(iterator);
	}
	
	static <T> AbstractEnumerator<T> enumerator(Iterator<T> iterator, Function<T, ?> toStringFunction){
		return new EnumeratorIterator(iterator).setFunction(toStringFunction);
	}
	
	static <T> AbstractEnumerator<T> enumerator(T... array){
		return new EnumeratorArray(array);
	}
	
	static <T> AbstractEnumerator<T> enumerator(T[] array, Function<T, ?> toStringFunction){
		return enumerator(toStringFunction, array);
	}
	
	static <T> AbstractEnumerator<T> enumerator(Function<T, ?> toStringFunction, T... array){
		return new EnumeratorArray(array).setFunction(toStringFunction);
	}
	
	static Enumerator enumerator(int... array){
		return new EnumeratorInt(array);
	}
	
	static Enumerator enumerator(IntFunction func, int... array){
		return new EnumeratorInt(array).setFunction(func);
	}
	
	static Enumerator enumerator(double... array){
		return new EnumeratorDouble(array);
	}
	
	static Enumerator enumerator(DoubleFunction func, double... array){
		return new EnumeratorDouble(array).setFunction(func);
	}
	
	static Enumerator enumerator(long... array){
		return new EnumeratorLong(array);
	}
	
	static Enumerator enumerator(LongFunction func, long... array){
		return new EnumeratorLong(array).setFunction(func);
	}
	
	static Enumerator enumerator(byte... array){
		return new EnumeratorInt(array);
	}
	
	static Enumerator enumerator(IntFunction func, byte... array){
		return new EnumeratorInt(array).setFunction(func);
	}
	
	static Enumerator enumerator(char... array){
		return new EnumeratorInt(array);
	}
	
	static Enumerator enumerator(IntFunction func, char... array){
		return new EnumeratorInt(array).setFunction(func);
	}
	
	static Enumerator enumerator(short... array){
		return new EnumeratorInt(array);
	}
	
	static Enumerator enumerator(IntFunction func, short... array){
		return new EnumeratorInt(array).setFunction(func);
	}
	
	static Enumerator enumerator(float... array){
		return new EnumeratorDouble(array);
	}
	
	static Enumerator enumerator(DoubleFunction func, float... array){
		return new EnumeratorDouble(array).setFunction(func);
	}
}
