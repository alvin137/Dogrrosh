package com.tictim.utilib;

import com.tictim.utilib.modeled.Modeled;
import com.tictim.utilib.util.ParticlePlacer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class CommonProxy{
	public void loadModel(){}
	public void registerModel(Modeled model, Item inst){}
	public void markModelBaked(){}
	
	public boolean isOp(EntityPlayer player){
		return FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getOppedPlayers().getPermissionLevel(player.getGameProfile())>=1;
	}
	
	public void placeParticle(ParticlePlacer particle){}
}
