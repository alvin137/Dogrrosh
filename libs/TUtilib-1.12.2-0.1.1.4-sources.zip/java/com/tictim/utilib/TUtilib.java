package com.tictim.utilib;

import com.tictim.utilib.config.Configs;
import com.tictim.utilib.event.Events;
import com.tictim.utilib.net.PlayerLogInMessage;
import com.tictim.utilib.util.TCreativeTab;
import com.tictim.utilib.util.TUtils;
import net.minecraft.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.registries.IForgeRegistry;

@Mod(modid = TUtilib.MODID, name = TUtilib.NAME, version = TUtilib.VERSION)
@EventBusSubscriber
public class TUtilib{
	public static final String MODID = "tutilib";
	public static final String NAME = "Tictim's Utility Library";
	public static final String VERSION = "0.1.1.4";
	
	@Instance(value = MODID)
	public static TUtilib instance;
	@SidedProxy(clientSide = "com.tictim.utilib.ClientProxy", serverSide = "com.tictim.utilib.CommonProxy")
	public static CommonProxy proxy;
	
	public static final SimpleNetworkWrapper CORE_NET = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
	
	static{
		CORE_NET.registerMessage(new PlayerLogInMessage.Listener(), PlayerLogInMessage.class, 0, Side.CLIENT);
	}
	
	public TUtilib(){
		TUtils.LOGGER.info(NAME+" "+VERSION);
	}
	
	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event){
		IForgeRegistry<Item> registry = event.getRegistry();
		TCreativeTab.registerAllIcons(registry);
		proxy.loadModel();
	}
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent event){
		Configs.loadConfig(event.getModConfigurationDirectory().getAbsolutePath(), TUtilib.MODID, CoreConfig.list);
		if(TUtils.isDevEnv()||CoreConfig.DEBUG_CONFIG.get()){
			Configs.loadConfig(event.getModConfigurationDirectory().getAbsolutePath(), "configtest", DebugConfig.list);
		}
	}
	
	@EventHandler
	public void init(FMLInitializationEvent event){
		proxy.markModelBaked();
		MinecraftForge.EVENT_BUS.register(Events.class);
		/*
		Events.addTickingTask(new Consumer<World>(){
			@Override
			public void accept(World world){
				if(world.getTotalWorldTime()%20==0)
					TUtils.LOGGER.info("WorldTick {}", world.isRemote ? "Client" : "Server");
			}
		}, true, true);
		*/
		/*
		UUID uid = UUID.randomUUID();
		NBTTagCompound nbt = new NBTTagCompound();
		
		NBTDecoder.TILEENTITY_OWNER_UUID.incode(nbt, uid);
		TUtils.LOGGER.info("test : "+nbt);
		TUtils.LOGGER.info("decode : "+NBTDecoder.TILEENTITY_OWNER_UUID.decode(nbt));
		
		uid = NBTDecoder.TILEENTITY_OWNER_UUID.decode(nbt);
		nbt = new NBTTagCompound();
		
		NBTDecoder.TILEENTITY_OWNER_UUID.incode(nbt, uid);
		TUtils.LOGGER.info("test2 : "+nbt);
		TUtils.LOGGER.info("decode2 : "+NBTDecoder.TILEENTITY_OWNER_UUID.decode(nbt));
		*/
	}
}
