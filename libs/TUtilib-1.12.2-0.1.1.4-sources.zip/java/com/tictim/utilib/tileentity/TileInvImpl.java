package com.tictim.utilib.tileentity;

import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class TileInvImpl extends TileInvBase{
	private int invSize;
	
	public TileInvImpl(){}
	
	public TileInvImpl(int invSize){
		this.invSize = invSize;
	}
	
	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack){
		return true;
	}
	
	@Override
	protected NonNullList<ItemStack> createInventoryList(){
		return NonNullList.withSize(invSize, ItemStack.EMPTY);
	}
	
	@Override
	protected String defaultName(){
		return "";
	}
	
}
