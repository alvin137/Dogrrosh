package com.tictim.utilib.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;

public abstract class TileInvBase extends TileBase implements IInventory{
	protected final NonNullList<ItemStack> inventory = createInventoryList();
	
	protected abstract NonNullList<ItemStack> createInventoryList();
	
	@Override
	public int getSizeInventory(){
		return inventory.size();
	}
	
	@Override
	public boolean isEmpty(){
		return inventory.isEmpty();
	}
	
	@Override
	public ItemStack getStackInSlot(int index){
		return inventory.get(index);
	}
	
	@Override
	public ItemStack decrStackSize(int index, int count){
		return ItemStackHelper.getAndSplit(this.inventory, index, count);
	}
	
	@Override
	public ItemStack removeStackFromSlot(int index){
		return ItemStackHelper.getAndRemove(this.inventory, index);
	}
	
	@Override
	public void setInventorySlotContents(int index, ItemStack stack){
		ItemStack itemstack = this.inventory.get(index);
		boolean flag = !stack.isEmpty()&&stack.isItemEqual(itemstack)&&ItemStack.areItemStackTagsEqual(stack, itemstack);
		this.inventory.set(index, stack);
		
		if(stack.getCount()>this.getInventoryStackLimit()){
			stack.setCount(this.getInventoryStackLimit());
		}
	}
	
	@Override
	public int getInventoryStackLimit(){
		return 64;
	}
	
	@Override
	public boolean isUsableByPlayer(EntityPlayer player){
		return getOwner().hasPermission(player);
	}
	
	@Override
	public void openInventory(EntityPlayer player){}
	@Override
	public void closeInventory(EntityPlayer player){}
	
	@Override
	public int getField(int id){
		return 0;
	}
	
	@Override
	public void setField(int id, int value){}
	
	@Override
	public int getFieldCount(){
		return 0;
	}
	
	@Override
	public void clear(){
		this.inventory.clear();
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbt){
		super.readFromNBT(nbt);
		ItemStackHelper.loadAllItems(nbt, this.inventory);
	}
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt){
		super.writeToNBT(nbt);
		ItemStackHelper.saveAllItems(nbt, this.inventory);
		return nbt;
	}
	
	public NBTTagCompound writeNBTForStack(){
		NBTTagCompound nbt = super.writeNBTForStack();
		if(keepInventoryInStack()) ItemStackHelper.saveAllItems(nbt, this.inventory);
		return nbt;
	}
	
	public boolean keepInventoryInStack(){
		return true;
	}
}
