package com.tictim.utilib.tileentity;

import javax.annotation.Nullable;
import com.tictim.utilib.nbt.NBTTypes;
import com.tictim.utilib.util.Owner;
import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;

public abstract class TileBase extends TileEntity implements IWorldNameable{
	private final Owner owner = new Owner();
	private String name;
	private boolean dropDisabled;
	
	@Override
	public String getName(){
		return hasCustomName() ? name : defaultName();
	}
	
	protected abstract String defaultName();
	
	@Override
	public boolean hasCustomName(){
		return name!=null&&!name.isEmpty();
	}
	
	public void setName(@Nullable String name){
		this.name = name;
	}
	
	public boolean isDropDisabled(){
		return this.dropDisabled;
	}
	
	public void setDropDisabled(boolean dropDisabled){
		this.dropDisabled = dropDisabled;
	}
	
	public Owner getOwner(){
		return this.owner;
	}
	
	@Override
	public ITextComponent getDisplayName(){
		return hasCustomName() ? new TextComponentString(getName()) : new TextComponentTranslation(getName());
	}
	
	@Override
	public boolean shouldRefresh(World world, BlockPos pos, IBlockState oldState, IBlockState newState){
		return oldState.getBlock()!=newState.getBlock();
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbt){
		super.readFromNBT(nbt);
		if(nbt.hasKey("name", NBTTypes.STRING)){
			this.name = nbt.getString("name");
		}
		if(nbt.hasKey("drop", NBTTypes.BOOLEAN)){
			this.dropDisabled = nbt.getBoolean("drop");
		}
		if(nbt.hasKey("owner", NBTTypes.COMPOUND)){
			this.owner.deserializeNBT(nbt.getCompoundTag("owner"));
		}
	}
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt){
		super.writeToNBT(nbt);
		if(name!=null) nbt.setString("name", name);
		if(dropDisabled) nbt.setBoolean("drop", true);
		if(this.owner.hasOwner()){
			nbt.setTag("owner", this.owner.serializeNBT());
		}
		return nbt;
	}
	
	public NBTTagCompound writeNBTForStack(){
		NBTTagCompound nbt = new NBTTagCompound();
		if(this.owner.hasOwner()){
			nbt.setTag("owner", this.owner.serializeNBT());
		}
		return nbt;
	}
}
