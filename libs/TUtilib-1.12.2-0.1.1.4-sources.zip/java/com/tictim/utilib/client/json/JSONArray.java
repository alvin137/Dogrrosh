package com.tictim.utilib.client.json;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class JSONArray extends JSONAppendable<JSONValue>{
	public JSONArray(boolean allowBreak, JSONValue... jsons){
		super(allowBreak, jsons);
	}
	
	@Override
	public String openingSignature(){
		return "[";
	}
	
	@Override
	public String closingSignature(){
		return "]";
	}
	
	public JSONArray append(boolean i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(boolean... i){
		for(boolean j : i)
			this.append(new JSONValue(j));
		return this;
	}
	
	public JSONArray append(long i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(long... i){
		for(long j : i)
			this.append(new JSONValue(j));
		return this;
	}
	
	public JSONArray append(int i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(int... i){
		for(int j : i)
			this.append(new JSONValue(j));
		return this;
	}
	
	public JSONArray append(float i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(float... i){
		for(float j : i)
			this.append(new JSONValue(j));
		return this;
	}
	
	public JSONArray append(double i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(double... i){
		for(double j : i)
			this.append(new JSONValue(j));
		return this;
	}
	
	public JSONArray append(String i){
		this.append(new JSONValue(i));
		return this;
	}
	
	public JSONArray append(String... i){
		for(String j : i)
			this.append(new JSONValue(j));
		return this;
	}
}
