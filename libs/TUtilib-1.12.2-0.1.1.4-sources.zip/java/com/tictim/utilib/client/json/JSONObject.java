package com.tictim.utilib.client.json;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class JSONObject extends JSONAppendable<JSONPair>{
	public JSONObject(boolean allowBreak, JSONPair... jsons){
		super(allowBreak, jsons);
	}
	
	@Override
	public String openingSignature(){
		return "{";
	}
	
	@Override
	public String closingSignature(){
		return "}";
	}
}
