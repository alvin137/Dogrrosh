package com.tictim.utilib.client.json;

import static com.tictim.utilib.client.json.JSONs.getTabs;
import java.util.List;
import com.google.common.collect.Lists;
import com.tictim.utilib.util.Enumerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public abstract class JSONAppendable<J extends JSONComponent> implements JSONComponent{
	protected final List<J> jsons;
	protected final boolean allowBreak;
	
	protected JSONAppendable(boolean allowBreak, J... jsons){
		this.allowBreak = allowBreak;
		this.jsons = Lists.newArrayList(jsons);
	}
	
	public abstract String openingSignature();
	public abstract String closingSignature();
	
	public JSONAppendable<J> append(J... json){
		for(J j : json)
			this.jsons.add(j);
		return this;
	}
	
	public JSONAppendable<J> append(J json){
		this.jsons.add(json);
		return this;
	}
	
	@Override
	public String toString(int numberOfTabs){
		String tab = getTabs(numberOfTabs+1);
		return this.openingSignature()+(allowBreak ? "\n"+tab : " ")+Enumerator.enumerator(jsons, j -> j.toString(numberOfTabs+1)).setDivider(allowBreak ? ",\n"+tab : ", ")+(allowBreak ? "\n"+getTabs(numberOfTabs) : " "+this.closingSignature());
	}
}
