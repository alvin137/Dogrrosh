package com.tictim.utilib.client.gui;

import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public abstract class GuiHandlerIdContaining implements IGuiHandler{
	private int guiHandlerId = -1;
	
	public GuiHandlerIdContaining registerTo(GuiHandler guiHandler){
		this.guiHandlerId = guiHandler.append(this);
		return this;
	}
	
	public void openGui(Object mod, EntityPlayer player, World world, @Nullable BlockPos blockPos){
		if(blockPos==null) blockPos = BlockPos.ORIGIN;
		openGui(mod, player, world, blockPos.getX(), blockPos.getY(), blockPos.getZ());
	}
	
	public void openGui(Object mod, EntityPlayer player, World world, int x, int y, int z){
		player.openGui(mod, this.guiHandlerId, world, x, y, z);
	}
}
