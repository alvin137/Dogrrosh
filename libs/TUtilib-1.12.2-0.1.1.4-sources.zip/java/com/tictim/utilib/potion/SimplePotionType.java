package com.tictim.utilib.potion;

import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;

public class SimplePotionType extends PotionType{
	private final String name;
	
	public SimplePotionType(String name, PotionEffect... effects){
		super(name, effects);
		this.name = name;
		this.setRegistryName(name);
	}
	
	@Deprecated
	public void register(){
		PotionType.registerPotionType(name, this);
	}
}
