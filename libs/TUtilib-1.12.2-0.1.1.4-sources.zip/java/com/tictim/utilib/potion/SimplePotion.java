package com.tictim.utilib.potion;

import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class SimplePotion extends NoRenderPotion{
	private final ResourceLocation texture;
	
	@Deprecated
	public SimplePotion(String modid, String name, boolean isBadEffectIn, int color){
		super(modid, name, isBadEffectIn, color);
		this.texture = new ResourceLocation(modid, "textures/potions/"+name+".png");
	}
	
	public SimplePotion(String name, boolean isBadEffectIn, int color){
		super(name, isBadEffectIn, color);
		this.texture = new ResourceLocation(this.getRegistryName().getResourceDomain(), "textures/potions/"+name+".png");
	}
	
	@Override
	public boolean shouldRender(PotionEffect effect){
		return true;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void renderInventoryEffect(int x, int y, PotionEffect effect, Minecraft mc){
		draw(x+6, y+7, mc, 1);
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void renderHUDEffect(int x, int y, PotionEffect effect, Minecraft mc, float alpha){
		draw(x+3, y+3, mc, alpha);
	}
	
	protected void draw(int x, int y, Minecraft mc, float alpha){
		GlStateManager.pushMatrix();
		mc.getTextureManager().bindTexture(this.texture);
		GlStateManager.color(1, 1, 1, alpha);
		BufferBuilder vb = Tessellator.getInstance().getBuffer();
		vb.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
		vb.pos(x, y+18, 0.0).tex(0, 1).endVertex();
		vb.pos(x+18, y+18, 0.0).tex(1, 1).endVertex();
		vb.pos(x+18, y, 0.0).tex(1, 0).endVertex();
		vb.pos(x, y, 0.0).tex(0, 0).endVertex();
		Tessellator.getInstance().draw();
		GlStateManager.popMatrix();
	}
}
