package com.tictim.utilib.potion;

import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.FMLContainer;
import net.minecraftforge.fml.common.InjectedModContainer;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;

public class NoRenderPotion extends Potion{
	public NoRenderPotion(String name, boolean isBadEffectIn, int color){
		this(getPrefix(), name, isBadEffectIn, color);
	}
	
	private static final String getPrefix(){
		ModContainer mc = Loader.instance().activeModContainer();
		return mc==null||(mc instanceof InjectedModContainer&&((InjectedModContainer)mc).wrappedContainer instanceof FMLContainer) ? "minecraft" : mc.getModId().toLowerCase();
	}
	
	@Deprecated
	public NoRenderPotion(String modid, String name, boolean isBadEffectIn, int color){
		super(isBadEffectIn, color);
		this.setRegistryName(name).setPotionName(modid+".effect."+name);
	}
	
	@Override
	public boolean shouldRender(PotionEffect effect){
		return false;
	}
}
