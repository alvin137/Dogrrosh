package com.tictim.utilib.modeled;

import com.tictim.utilib.TUtilib;
import com.tictim.utilib.util.TUtils;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.registries.IForgeRegistry;

public final class ModelLoadHelper{
	private ModelLoadHelper(){}
	
	public static void registerItemAndModels(IForgeRegistry<Item> registry, Item item){
		registry.register(item);
		if(item instanceof Modeled){
			TUtilib.proxy.registerModel((Modeled)item, item);
		}
	}
	
	public static void registerItemAndModels(IForgeRegistry<Item> registry, Block block){
		ItemBlock item = TUtils.createItemBlock(block);
		registry.register(item);
		if(block instanceof Modeled){
			TUtilib.proxy.registerModel((Modeled)block, item);
		}
	}
}
