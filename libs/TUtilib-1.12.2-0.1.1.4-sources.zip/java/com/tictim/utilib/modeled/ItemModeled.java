package com.tictim.utilib.modeled;

import net.minecraft.item.Item;

public class ItemModeled extends Item implements Modeled{}
