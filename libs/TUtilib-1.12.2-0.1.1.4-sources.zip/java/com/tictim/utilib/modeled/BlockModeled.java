package com.tictim.utilib.modeled;

import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.DefaultStateMapper;
import net.minecraft.client.renderer.block.statemap.IStateMapper;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockModeled extends Block implements Modeled{
	public BlockModeled(Material material){
		super(material);
	}
	
	public BlockModeled(Material material, MapColor color){
		super(material, color);
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void registerModels(Item inst){
		ModelLoader.setCustomStateMapper(this, getBlockStateMapper());
		ModelLoader.setCustomModelResourceLocation(inst, 0, new ModelResourceLocation(inst.getRegistryName(), "inventory"));
	}
	
	@SideOnly(Side.CLIENT)
	protected IStateMapper getBlockStateMapper(){
		return new DefaultStateMapper();
	}
}
