package com.tictim.utilib.modeled;

import com.tictim.utilib.tileentity.TileBase;
import com.tictim.utilib.util.TUtils;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class BlockBase<T extends TileBase>extends Block implements Modeled, ITileEntityProvider{
	public BlockBase(Material material){
		super(material);
	}
	
	@Override
	public void onBlockPlacedBy(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack){
		T te = TUtils.getTE(world, pos);
		if(te!=null){
			if(stack.hasDisplayName()){
				te.setName(stack.getDisplayName());
			}
			if(!te.getOwner().hasOwner()&&placer instanceof EntityPlayer){
				EntityPlayer p = (EntityPlayer)placer;
				//TUtils.LOGGER.info("Inject owner {} ({}) to TileEntity on {}, [{}, {}, {}]", p.getName(), EntityPlayer.getUUID(p.getGameProfile()), world.provider.getDimension(), pos.getX(), pos.getY(), pos.getZ());
				te.getOwner().setOwner(EntityPlayer.getUUID(p.getGameProfile()), p.getName());
				te.getOwner().setPublic(true);
			}
		}
	}
	
	@Override
	public void onBlockHarvested(World world, BlockPos pos, IBlockState state, EntityPlayer player){
		if(player.capabilities.isCreativeMode){
			T te = TUtils.getTE(world, pos);
			if(te!=null) te.setDropDisabled(true);
		}
	}
	
	@Override
	public void dropBlockAsItemWithChance(World world, BlockPos pos, IBlockState state, float chance, int fortune){}
	
	@Override
	public void breakBlock(World world, BlockPos pos, IBlockState state){
		T te = TUtils.getTE(world, pos);
		if(te!=null){
			if(!te.isDropDisabled()){
				ItemStack stack = this.getItem(world, pos, state);
				spawnAsEntity(world, pos, stack);
			}
		}
		super.breakBlock(world, pos, state);
	}
	
	@Override
	public ItemStack getItem(World world, BlockPos pos, IBlockState state){
		ItemStack stack = super.getItem(world, pos, state);
		T te = TUtils.getTE(world, pos);
		if(te!=null){
			NBTTagCompound subnbt = te.writeNBTForStack();
			if(!subnbt.hasNoTags()){
				NBTTagCompound nbt = new NBTTagCompound();
				nbt.setTag(TUtils.KEY_BLOCK_ENTITY_TAG, subnbt);
				stack.setTagCompound(nbt);
			}
			if(te.hasCustomName()){
				stack.setStackDisplayName(te.getName());
				te.getDisplayName();
			}
		}
		return stack;
	}
	
	@Override
	public EnumBlockRenderType getRenderType(IBlockState state){
		return EnumBlockRenderType.MODEL;
	}
	
	@Override
	public abstract T createNewTileEntity(World world, int meta);
}
