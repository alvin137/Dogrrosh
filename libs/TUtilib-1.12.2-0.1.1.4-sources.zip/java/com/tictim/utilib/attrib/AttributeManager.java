package com.tictim.utilib.attrib;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiFunction;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterators;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.nbt.NBTTagList;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class AttributeManager implements INBTSerializable<NBTTagList>, Iterable<AttributeData>{
	private final Map<String, AttributeCompound> attribs = Maps.newHashMap();
	
	public void addAttribute(AttributeManager a){
		for(AttributeCompound b : a.attribs.values())
			addAttribute(b);
	}
	
	public void addAttribute(AttributeCompound a){
		for(AttributeData b : a.getAttribs())
			getCompoundAt(b.getName()).append(b);
	}
	
	public void addAttribute(AttributeData a){
		getCompoundAt(a.getName()).append(a);
	}
	
	public void addAttribute(IAttribute attrib, double amount, int operation){
		addAttribute(new AttributeData(attrib, amount, operation));
	}
	
	public void addAttribute(String attribName, double amount, int operation){
		addAttribute(new AttributeData(attribName, amount, operation));
	}
	
	private AttributeCompound getCompoundAt(String attribName){
		if(this.attribs.containsKey(attribName)) return this.attribs.get(attribName);
		else{
			AttributeCompound attrib = new AttributeCompound(attribName);
			this.attribs.put(attribName, attrib);
			return attrib;
		}
	}
	
	@Override
	public Iterator<AttributeData> iterator(){
		return Iterators.concat(this.attribs.values().stream().map(e -> e.iterator()).iterator());
	}
	
	public boolean isEmpty(){
		for(AttributeCompound e : this.attribs.values()){
			if(!e.isEmpty()) return false;
		}
		return true;
	}
	
	@SideOnly(Side.CLIENT)
	public void addDescription(List<String> strings){
		for(AttributeCompound e : this.attribs.values()){
			e.addDescription(strings);
		}
	}
	
	public void clear(){
		this.attribs.clear();
	}
	
	@Override
	public NBTTagList serializeNBT(){
		NBTTagList list = new NBTTagList();
		for(AttributeCompound e : this.attribs.values()){
			e.serializeNBT(list);
		}
		return list;
	}
	
	@Override
	public void deserializeNBT(NBTTagList list){
		this.attribs.clear();
		for(int i = 0, j = list.tagCount(); i<j; i++){
			addAttribute(AttributeData.deserialize(list.getCompoundTagAt(i)));
		}
	}
	
	public static Multimap<String, AttributeModifier> getAttributes(Iterable<AttributeData> attrib, BiFunction<String, Integer, UUID> uuidFunc){
		Multimap<String, AttributeModifier> map = HashMultimap.create();
		for(AttributeData e : attrib){
			map.put(e.getName(), e.getAttribModifier(uuidFunc.apply(e.getName(), e.getOperation())));
		}
		return map;
	}
}
