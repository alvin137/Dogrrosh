package com.tictim.utilib.attrib;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.google.common.collect.Maps;
import net.minecraft.nbt.NBTTagList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class AttributeCompound implements Iterable<AttributeData>{
	private final String keyName;
	private final Map<Integer, AttributeData> data = Maps.newHashMap();
	
	public AttributeCompound(String keyName){
		this.keyName = keyName;
	}
	
	@Override
	public Iterator<AttributeData> iterator(){
		return data.values().iterator();
	}
	
	public void append(AttributeData attrib){
		if(!keyName.equals(attrib.getName())) throw new IllegalArgumentException();
		else{
			Integer i = attrib.getOperation();
			if(data.containsKey(i)){
				AttributeData old = data.get(i);
				if(attrib.getValue()+old.getValue()==0) data.remove(i);
				else data.put(i, new AttributeData(attrib.getName(), attrib.getValue()+old.getValue(), i));
			}else data.put(i, attrib);
		}
	}
	
	@SideOnly(Side.CLIENT)
	public void addDescription(List<String> strings){
		for(AttributeData e : data.values()){
			strings.add(e.toString());
		}
	}
	
	public Collection<AttributeData> getAttribs(){
		return Collections.unmodifiableCollection(this.data.values());
	}
	
	public boolean isEmpty(){
		return this.data.isEmpty();
	}
	
	public void serializeNBT(NBTTagList list){
		for(AttributeData data : this.data.values())
			list.appendTag(data.serializeNBT());
	}
}
