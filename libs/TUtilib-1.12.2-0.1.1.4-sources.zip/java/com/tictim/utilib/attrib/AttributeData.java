package com.tictim.utilib.attrib;

import java.util.Iterator;
import java.util.UUID;
import com.google.common.collect.Iterators;
import com.tictim.utilib.util.TUtils;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.util.INBTSerializable;

public class AttributeData implements INBTSerializable<NBTTagCompound>, Iterable<AttributeData>{
	protected final String attrib;
	protected final double value;
	protected final int operation;
	
	public AttributeData(IAttribute attrib, double value, int operation){
		this(attrib.getName(), value, operation);
	}
	
	public AttributeData(String attrib, double value, int operation){
		this.attrib = attrib;
		this.value = value;
		this.operation = operation;
	}
	
	public String getName(){
		return this.attrib;
	}
	
	public double getValue(){
		return this.value;
	}
	
	public int getOperation(){
		return this.operation;
	}
	
	public String localize(){
		return localize(false);
	}
	
	public String localize(boolean eq){
		return TUtils.localizeAttrib(this.attrib, this.value, this.operation, eq, false);
	}
	
	public boolean isEmpty(){
		return this.value==0;
	}
	
	@Override
	public Iterator<AttributeData> iterator(){
		return Iterators.singletonIterator(this);
	}
	
	public AttributeModifier getAttribModifier(UUID uuid){
		return new AttributeModifier(uuid, getName(), getValue(), getOperation());
	}
	
	@Override
	public boolean equals(Object o){
		if(o==this) return true;
		else if(!(o instanceof AttributeData)) return false;
		else{
			AttributeData a = (AttributeData)o;
			return this.attrib==a.attrib&&this.value==a.value&&this.operation==a.operation;
		}
	}
	
	@Override
	public NBTTagCompound serializeNBT(){
		NBTTagCompound nbt = new NBTTagCompound();
		nbt.setString("attrib", this.attrib);
		nbt.setDouble("value", this.value);
		nbt.setInteger("operation", this.operation);
		return nbt;
	}
	
	@Override
	public void deserializeNBT(NBTTagCompound nbt){}
	
	public static final AttributeData deserialize(NBTTagCompound nbt){
		return new AttributeData(nbt.getString("attrib"), nbt.getDouble("value"), nbt.getInteger("operation"));
	}
}
