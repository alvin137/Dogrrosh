package com.tictim.utilib.nbt;

import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;

public class NBTDecoderInventory implements NBTDecoder<NonNullList<ItemStack>>{
	protected final int invSize;
	
	public NBTDecoderInventory(int invSize){
		if(invSize<0) throw new RuntimeException("NBTDecoderInventory cannot have negative slot size");
		this.invSize = invSize;
	}
	
	@Override
	public NonNullList<ItemStack> decode(NBTTagCompound nbt){
		NonNullList<ItemStack> inv = NonNullList.withSize(invSize, ItemStack.EMPTY);
		ItemStackHelper.loadAllItems(nbt, inv);
		return inv;
	}
	
	@Override
	public boolean hasTag(NBTTagCompound nbt){
		return nbt.hasKey("tag", NBTTypes.LIST);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, NonNullList<ItemStack> inst){
		ItemStackHelper.saveAllItems(nbt, inst);
	}
}
