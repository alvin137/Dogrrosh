package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderDouble extends AbstractNBTDecoder<Double>{
	public NBTDecoderDouble(String key){
		super(key);
	}
	
	@Override
	public Double decode(NBTTagCompound nbt){
		return nbt.getDouble(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Double inst){
		nbt.setDouble(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.DOUBLE;
	}
}
