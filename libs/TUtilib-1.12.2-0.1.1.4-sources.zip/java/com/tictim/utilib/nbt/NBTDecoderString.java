package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderString extends AbstractNBTDecoder<String>{
	public NBTDecoderString(String key){
		super(key);
	}
	
	@Override
	public String decode(NBTTagCompound nbt){
		return nbt.getString(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, String inst){
		nbt.setString(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.STRING;
	}
}
