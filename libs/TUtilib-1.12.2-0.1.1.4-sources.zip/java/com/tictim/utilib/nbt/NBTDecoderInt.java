package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderInt extends AbstractNBTDecoder<Integer>{
	public NBTDecoderInt(String key){
		super(key);
	}
	
	@Override
	public Integer decode(NBTTagCompound nbt){
		return nbt.getInteger(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Integer inst){
		nbt.setInteger(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.INTEGER;
	}
}
