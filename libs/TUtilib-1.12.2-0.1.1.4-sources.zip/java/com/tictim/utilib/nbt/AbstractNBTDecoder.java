package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public abstract class AbstractNBTDecoder<T> implements NBTDecoder<T>{
	protected final String key;
	
	public AbstractNBTDecoder(String key){
		this.key = key;
	}
	
	@Override
	public boolean hasTag(NBTTagCompound nbt){
		return nbt.hasKey(key(), nbtType());
	}
	
	protected String key(){
		return this.key;
	}
	
	protected abstract int nbtType();
}
