package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderIntArray extends AbstractNBTDecoder<int[]>{
	public NBTDecoderIntArray(String key){
		super(key);
	}
	
	@Override
	public int[] decode(NBTTagCompound nbt){
		return nbt.getIntArray(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, int[] inst){
		nbt.setIntArray(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.INT_ARRAY;
	}
}
