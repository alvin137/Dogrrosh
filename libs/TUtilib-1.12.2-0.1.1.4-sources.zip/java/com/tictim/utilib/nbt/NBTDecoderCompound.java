package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderCompound extends AbstractNBTDecoder<NBTTagCompound>{
	public NBTDecoderCompound(String key){
		super(key);
	}
	
	@Override
	public NBTTagCompound decode(NBTTagCompound nbt){
		return nbt.getCompoundTag(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, NBTTagCompound inst){
		nbt.setTag(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.COMPOUND;
	}
}
