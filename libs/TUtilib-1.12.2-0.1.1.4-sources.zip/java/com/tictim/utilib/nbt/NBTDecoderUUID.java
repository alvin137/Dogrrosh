package com.tictim.utilib.nbt;

import java.util.UUID;
import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderUUID implements NBTDecoder<UUID>{
	protected final String key;
	
	public NBTDecoderUUID(String key){
		this.key = key;
	}
	
	@Override
	public UUID decode(NBTTagCompound nbt){
		return nbt.getUniqueId(key);
	}
	
	@Override
	public boolean hasTag(NBTTagCompound nbt){
		return nbt.hasUniqueId(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, UUID inst){
		nbt.setUniqueId(key, inst);
	}
}
