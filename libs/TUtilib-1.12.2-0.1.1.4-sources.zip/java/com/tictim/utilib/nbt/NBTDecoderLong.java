package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderLong extends AbstractNBTDecoder<Long>{
	public NBTDecoderLong(String key){
		super(key);
	}
	
	@Override
	public Long decode(NBTTagCompound nbt){
		return nbt.getLong(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Long inst){
		nbt.setLong(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.LONG;
	}
}
