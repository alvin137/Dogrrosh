package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderBoolean extends AbstractNBTDecoder<Boolean>{
	public NBTDecoderBoolean(String key){
		super(key);
	}
	
	@Override
	public Boolean decode(NBTTagCompound nbt){
		return nbt.getBoolean(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Boolean inst){
		nbt.setBoolean(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.BOOLEAN;
	}
}
