package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderByte extends AbstractNBTDecoder<Byte>{
	public NBTDecoderByte(String key){
		super(key);
	}
	
	@Override
	public Byte decode(NBTTagCompound nbt){
		return nbt.getByte(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Byte inst){
		nbt.setByte(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.BYTE;
	}
}
