package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderByteArray extends AbstractNBTDecoder<byte[]>{
	public NBTDecoderByteArray(String key){
		super(key);
	}
	
	@Override
	public byte[] decode(NBTTagCompound nbt){
		return nbt.getByteArray(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, byte[] inst){
		nbt.setByteArray(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.BYTE_ARRAY;
	}
}
