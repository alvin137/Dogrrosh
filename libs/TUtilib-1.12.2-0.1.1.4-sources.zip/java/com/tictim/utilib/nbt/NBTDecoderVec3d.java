package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.Vec3d;

public class NBTDecoderVec3d implements NBTDecoder<Vec3d>{
	protected final String key;
	
	public NBTDecoderVec3d(String key){
		this.key = key;
	}
	
	@Override
	public Vec3d decode(NBTTagCompound nbt){
		return new Vec3d(nbt.getDouble("x"), nbt.getDouble("y"), nbt.getDouble("z"));
	}
	
	@Override
	public boolean hasTag(NBTTagCompound nbt){
		return nbt.hasKey("x", NBTTypes.DOUBLE)&&nbt.hasKey("y", NBTTypes.DOUBLE)&&nbt.hasKey("z", NBTTypes.DOUBLE);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Vec3d inst){
		nbt.setDouble("x", inst.x);
		nbt.setDouble("y", inst.y);
		nbt.setDouble("z", inst.z);
	}
}
