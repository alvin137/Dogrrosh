package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class NBTDecoderList extends AbstractNBTDecoder<NBTTagList>{
	private final int elementType;
	
	public NBTDecoderList(String key, int elementType){
		super(key);
		this.elementType = elementType;
	}
	
	@Override
	public NBTTagList decode(NBTTagCompound nbt){
		return nbt.getTagList(key, elementType);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, NBTTagList inst){
		nbt.setTag(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.LIST;
	}
}
