package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderShort extends AbstractNBTDecoder<Short>{
	public NBTDecoderShort(String key){
		super(key);
	}
	
	@Override
	public Short decode(NBTTagCompound nbt){
		return nbt.getShort(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Short inst){
		nbt.setShort(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.SHORT;
	}
}
