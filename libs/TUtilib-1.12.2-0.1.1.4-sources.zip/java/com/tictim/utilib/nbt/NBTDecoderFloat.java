package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;

public class NBTDecoderFloat extends AbstractNBTDecoder<Float>{
	public NBTDecoderFloat(String key){
		super(key);
	}
	
	@Override
	public Float decode(NBTTagCompound nbt){
		return nbt.getFloat(key);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, Float inst){
		nbt.setFloat(key, inst);
	}
	
	@Override
	protected int nbtType(){
		return NBTTypes.FLOAT;
	}
}
