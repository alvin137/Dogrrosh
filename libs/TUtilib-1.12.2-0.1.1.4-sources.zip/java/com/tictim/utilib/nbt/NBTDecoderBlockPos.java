package com.tictim.utilib.nbt;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.BlockPos;

public class NBTDecoderBlockPos implements NBTDecoder<BlockPos>{
	protected final String key;
	
	public NBTDecoderBlockPos(String key){
		this.key = key;
	}
	
	@Override
	public BlockPos decode(NBTTagCompound nbt){
		return new BlockPos(nbt.getInteger("x"), nbt.getInteger("y"), nbt.getInteger("z"));
	}
	
	@Override
	public boolean hasTag(NBTTagCompound nbt){
		return nbt.hasKey("x", NBTTypes.INTEGER)&&nbt.hasKey("y", NBTTypes.INTEGER)&&nbt.hasKey("z", NBTTypes.INTEGER);
	}
	
	@Override
	public void incode(NBTTagCompound nbt, BlockPos inst){
		nbt.setInteger("x", inst.getX());
		nbt.setInteger("y", inst.getY());
		nbt.setInteger("z", inst.getZ());
	}
}
