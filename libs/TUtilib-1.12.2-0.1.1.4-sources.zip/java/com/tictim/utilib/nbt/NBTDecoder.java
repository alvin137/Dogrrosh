package com.tictim.utilib.nbt;

import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import com.tictim.utilib.util.TUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

/**
 * NBTDecoder�� NBTTagCompound���� �����͸� �ս��� �������� ���� ������� �������� ���� �������̽��Դϴ�.
 * @author user
 *
 */
public interface NBTDecoder<T>{
	public static final NBTDecoder<NBTTagCompound> TILEENTITY_NBT = new NBTDecoderCompound(TUtils.KEY_BLOCK_ENTITY_TAG);
	public static final NBTDecoder<UUID> TILEENTITY_OWNER_UUID = new NBTDecoderUUID("owner").setSuper(new NBTDecoderCompound("owner")).setSuper(TILEENTITY_NBT);
	public static final NBTDecoder<String> TILEENTITY_OWNER_NAME = new NBTDecoderString("ownerName").setSuper(new NBTDecoderCompound("owner")).setSuper(TILEENTITY_NBT);
	
	T decode(NBTTagCompound nbt);
	boolean hasTag(NBTTagCompound nbt);
	void incode(NBTTagCompound nbt, T inst);
	
	@Nullable
	default T decode(ItemStack stack){
		return stack.hasTagCompound() ? decode(stack.getTagCompound()) : null;
	}
	
	default boolean hasTag(ItemStack stack){
		return stack.hasTagCompound()&&hasTag(stack.getTagCompound());
	}
	
	default void incode(ItemStack stack, T inst){
		NBTTagCompound nbt = stack.getTagCompound();
		if(nbt==null){
			stack.setTagCompound(nbt = new NBTTagCompound());
		}
		incode(nbt, inst);
	}
	
	default <K> NBTDecoder<K> map(Function<T, K> convert, Function<K, T> restore){
		return new NBTDecoder<K>(){
			@Override
			public K decode(NBTTagCompound nbt){
				return convert.apply(NBTDecoder.this.decode(nbt));
			}
			
			@Override
			public boolean hasTag(NBTTagCompound nbt){
				return NBTDecoder.this.hasTag(nbt);
			}
			
			@Override
			public void incode(NBTTagCompound nbt, K inst){
				NBTDecoder.this.incode(nbt, restore.apply(inst));
			}
		};
	}
	
	default NBTDecoder<T> setSuper(NBTDecoder<NBTTagCompound> decoder){
		return new NBTDecoder<T>(){
			@Override
			public T decode(NBTTagCompound nbt){
				return NBTDecoder.this.decode(decoder.decode(nbt));
			}
			
			@Override
			public boolean hasTag(NBTTagCompound nbt){
				return decoder.hasTag(nbt)&&NBTDecoder.this.hasTag(decoder.decode(nbt));
			}
			
			@Override
			public void incode(NBTTagCompound nbt, T inst){
				NBTTagCompound subnbt = new NBTTagCompound();
				NBTDecoder.this.incode(subnbt, inst);
				decoder.incode(nbt, subnbt);
			}
		};
	}
}
