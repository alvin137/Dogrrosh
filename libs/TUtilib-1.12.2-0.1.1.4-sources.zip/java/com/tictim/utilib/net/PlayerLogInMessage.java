package com.tictim.utilib.net;

import com.tictim.utilib.config.Config;
import com.tictim.utilib.config.Configs;
import com.tictim.utilib.nbt.NBTTypes;
import com.tictim.utilib.util.TUtils;
import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PlayerLogInMessage implements IMessage{
	@Override
	public void fromBytes(ByteBuf buf){
		TUtils.LOGGER.debug("Unpacking config packet");
		NBTTagCompound nbt = ByteBufUtils.readTag(buf);
		for(String str : Configs.SYNCABLE_LOADED_CONFIGS.keySet()){
			if(nbt.hasKey(str, NBTTypes.COMPOUND)){
				NBTTagCompound subnbt = nbt.getCompoundTag(str);
				for(Config cfg : Configs.SYNCABLE_LOADED_CONFIGS.get(str)){
					if(cfg.getType().sync(subnbt, cfg)){
						cfg.onSync();
						TUtils.LOGGER.debug("Synced "+cfg+" = "+cfg.get());
					}else TUtils.LOGGER.warn("Failed to sync "+cfg+" = "+cfg.get());
				}
			}else TUtils.LOGGER.warn("Cannot found loader group "+str);
		}
	}
	
	@Override
	public void toBytes(ByteBuf buf){
		TUtils.LOGGER.debug("Packing config packet");
		NBTTagCompound nbt = new NBTTagCompound();
		Configs.SYNCABLE_LOADED_CONFIGS.asMap().forEach((loader, collection) -> {
			NBTTagCompound subnbt = new NBTTagCompound();
			collection.forEach(cfg -> {
				cfg.getType().serializeTo(subnbt, cfg);
				TUtils.LOGGER.debug("Packed "+cfg.getIdentificationString()+" = "+cfg.get());
			});
			nbt.setTag(loader, subnbt);
		});
		ByteBufUtils.writeTag(buf, nbt);
	}
	
	public static class Listener implements IMessageHandler<PlayerLogInMessage, IMessage>{
		@Override
		public IMessage onMessage(PlayerLogInMessage message, MessageContext ctx){
			return null;
		}
	}
}
