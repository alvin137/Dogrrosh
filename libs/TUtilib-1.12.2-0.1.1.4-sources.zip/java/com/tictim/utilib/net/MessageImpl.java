package com.tictim.utilib.net;

import com.tictim.utilib.util.TUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

public interface MessageImpl extends IMessage{
	default void send(EntityPlayer player){
		if(player instanceof EntityPlayerMP) getNetworkWrapper().sendTo(this, (EntityPlayerMP)player);
		else TUtils.LOGGER.warn("Cannot send message {} to player {}, not EntityPlayerMP", this, player.getName());
	}
	
	default void sendToAll(){
		getNetworkWrapper().sendToAll(this);
	}
	
	default void sendToTarget(int dim, double x, double y, double z, double range){
		getNetworkWrapper().sendToAllAround(this, new TargetPoint(dim, x, y, z, range));
	}
	
	default void sendToDim(int dim){
		getNetworkWrapper().sendToDimension(this, dim);
	}
	
	default void sendToServer(){
		getNetworkWrapper().sendToServer(this);
	}
	
	SimpleNetworkWrapper getNetworkWrapper();
}
